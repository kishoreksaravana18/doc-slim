---
name: Bug report
about: Something is not working
---

**Describe the bug**

**To reproduce**
Command run, document type (do not attach confidential documents), and output.

**Expected behavior**

**Environment**
OS, Python version, package version.
