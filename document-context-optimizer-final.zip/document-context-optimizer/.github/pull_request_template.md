## Summary

## Checklist
- [ ] `pytest` passes
- [ ] `ruff check .` passes
- [ ] No user documents or workspace data committed
- [ ] Docs/CHANGELOG updated if behavior changed
- [ ] Performance claims backed by committed benchmark output
