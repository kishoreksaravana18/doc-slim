# Changelog

## 0.1.0 (2026-07-11)

Initial release.

- Claude Agent Skill (SKILL.md) with references, examples, and templates
- Local extraction for PDF, DOCX, TXT, Markdown, HTML
- Scanned-page detection with optional Tesseract OCR
- Semantic chunking with structure preservation and stable chunk IDs
- Hash-keyed local index with reuse and validation
- Staged BM25 retrieval: metadata filters, reranking, dedup, token budgets, conditional neighbor expansion
- Compact document maps and compact session memory
- Local token estimation and dual-baseline benchmarking
- Security controls: path containment, filename sanitization, size limits, secret-redacting logs
- Test suite and GitHub Actions CI
