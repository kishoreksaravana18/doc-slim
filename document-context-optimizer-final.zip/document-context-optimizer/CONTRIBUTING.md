# Contributing

1. Fork and clone the repo, then: `python -m venv .venv && source .venv/bin/activate && pip install -e ".[dev]"`
2. Run checks before opening a PR: `ruff check .`, `pytest`
3. Keep the default dependency list small; new heavy dependencies need justification.
4. Never commit user documents, extracted text, indexes, or workspace data.
5. Match measured results to claims: any performance statement in docs must be backed by `benchmark.py` output committed to `benchmarks/results/`.
6. Follow semantic versioning; add a CHANGELOG entry with every user-visible change.
