# document-context-optimizer

A Claude Agent Skill and local retrieval toolkit that reduces repeated long-document context usage by indexing files and loading only the sections needed for each question.

> **Important limitation:** This project does not control how every Claude interface initially processes an uploaded file. Its measurable benefit comes from reusable local indexing, selective retrieval, and smaller downstream context packages.

## The problem

Working with a 150-page contract or annual report in a chat means the full document, or a lossy summary, tends to travel with every question. That wastes context, slows answers, and drops page-level traceability. This toolkit indexes a document once, then answers each question from the 3 to 6 most relevant chunks, with page and section citations, and reuses that index for every follow-up.

## How it works

```mermaid
flowchart LR
    A[Document] --> B[Inspection]
    B --> C[Extraction]
    C --> D[Semantic Chunking]
    D --> E[Local Index]
    Q[User Question] --> F[Retrieval]
    E --> F
    F --> G[Selected Evidence]
    G --> H[Claude Answer]
    H --> I[Compact Session Memory]
    I --> F
```

Two layers:

1. **Claude Agent Skill** (`document-context-optimizer/SKILL.md`): tells Claude when to activate, how to search before reading, how to cite pages and sections, how to keep compact memory, and how to treat document content as untrusted data.
2. **Local retrieval engine** (`document-context-optimizer/scripts/`): pure-Python extraction, semantic chunking, hash-keyed index reuse, staged BM25 retrieval with token budgets, validation, and benchmarking. Runs entirely locally. No vector database. No API key required.

## Features

- PDF, DOCX, TXT, Markdown, and HTML extraction with page and heading preservation
- Scanned-page detection with optional Tesseract OCR (uncertain values flagged, never silently corrected)
- Semantic chunking that keeps headings with their paragraphs, clauses with subclauses, and tables whole
- SHA-256 keyed index reuse: an unchanged document is never re-extracted
- Staged retrieval: metadata filters, BM25, reranking, deduplication, token-budgeted selection, conditional neighbor expansion
- Compact document maps and compact session memory (never full text)
- Local token estimation with dual-baseline benchmark reports
- Security controls: path containment, filename sanitization, size limits, secret-redacting logs, prompt-injection guidance

## Supported formats

PDF, DOCX, TXT, Markdown, HTML. RTF, EPUB, PPTX, CSV, and XLSX are not supported in v0.1.

## Installation

```bash
git clone https://github.com/kishoresaravana/document-context-optimizer.git
cd document-context-optimizer
python3 -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\Activate.ps1
pip install -e .
```

Optional extras: `pip install -e ".[ocr]"` (plus system tesseract) for scanned PDFs, `pip install -e ".[dev]"` for tests and linting. Full instructions, including Windows details, in `docs/installation.md`.

### Installing the Claude Agent Skill

The skill is the inner `document-context-optimizer/` folder (the one containing `SKILL.md`). For Claude Code, copy or symlink it into `.claude/skills/` in your project or `~/.claude/skills/` for personal use. For Claude.ai, upload it through Settings > Capabilities > Skills where available. See `docs/installation.md`.

## Usage

```bash
doc-context inspect report.pdf
doc-context index report.pdf
doc-context search <document_id> "termination for convenience"
doc-context context <document_id> "termination for convenience"
doc-context validate <document_id>
doc-context clean <document_id>       # remove all local data for a document
```

Script-level commands and the typical Claude workflow are in `docs/usage.md`. Worked examples for contracts, research papers, annual reports, and multi-document comparisons are in `document-context-optimizer/examples/`.

## Benchmarks

Methodology in `docs/benchmarking.md`. Two baselines are always reported: full document per question (Baseline A) and full document once plus growing conversation (Baseline B). All token figures are local estimates, not exact API billing counts. Run `python benchmarks/run_benchmarks.py`; results land in `benchmarks/results/`. Current committed results (synthetic fixtures, local token estimates):

| Case | Doc tokens (est.) | Questions | Reduction vs Baseline A | Reduction vs Baseline B | Avg chunks/question |
|---|---|---|---|---|---|
| 144-page synthetic annual report | 49,088 | 5 | 96.3% | 87.2% | 1.0 |
| Short synthetic contract (~1 page) | 418 | 4 | 22.1% | 25.2% | 1.5 |
| Tiny DOCX policy | 64 | 2 | -69.5% | 53.8% | 1.0 |

The tiny-document case honestly shows negative reduction against Baseline A: for documents below the activation thresholds (~15 pages / ~8,000 tokens), full-context reading is cheaper, which is exactly why the skill does not activate there. Larger and scanned-document benchmarks are planned for v0.2. Performance targets in the docs are engineering targets, not achieved claims, until committed reports demonstrate them.

## Privacy

Everything runs locally by default. No document content is sent to a vector database, OCR provider, embedding API, or analytics service. Optional external integrations (future versions) will be disabled by default and clearly documented. `doc-context clean <id>` removes all extracted text, chunks, indexes, OCR artifacts, memory, and reports for a document.

## Security

Document content is treated as untrusted data: embedded instructions are never followed, scripts and macros are never executed, links are never auto-followed, and passwords or DRM are never bypassed. Engine-level controls include path containment, filename sanitization, file-size limits, and secret redaction in logs. Full policy in `SECURITY.md` and `document-context-optimizer/references/security-rules.md`.

## Limitations

See `docs/limitations.md`. Highlights: token counts are estimates; table extraction and OCR are heuristic; lexical retrieval can miss purely semantic matches; DOCX citations use section headings rather than pages; v0.1 is tuned for English.

## Roadmap

- **0.1**: core local extraction, semantic chunking, lexical retrieval, token estimates, index reuse, Agent Skill, PDF/DOCX/TXT/MD/HTML, tests, docs
- **0.2**: better table extraction, optional local embeddings, improved OCR, multi-document collections, expanded benchmark suite with large fixtures
- **0.3**: incremental indexing, cross-reference resolution, document-version comparison, optional Anthropic token-counting integration, prompt-caching examples

## Contributing

See `CONTRIBUTING.md`. Short version: install dev extras, run `ruff check .` and `pytest`, never commit user documents or workspace data, and back any performance claim with committed benchmark output.

## License

MIT. See `LICENSE`.

## Acknowledgments

Built for the Claude Agent Skills format. Uses PyMuPDF, python-docx, and Beautiful Soup for extraction.
