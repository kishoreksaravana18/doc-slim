# Security policy

## Model
Document content is treated as untrusted data. The engine never executes embedded scripts or macros, never follows links, and never uploads content externally. The Agent Skill instructs Claude to ignore operational instructions found inside documents (prompt injection).

## Controls
- Filename sanitization and path containment inside `workspace/`
- File-size limit (200 MB default) and extension validation
- Secret redaction in logs; full document text never logged by default
- No API key required; everything runs locally by default
- Passwords, encryption, and DRM are never bypassed

## Reporting
Report vulnerabilities privately via GitHub Security Advisories on this repository. Do not open public issues for security reports. You can expect an initial response within 7 days.
