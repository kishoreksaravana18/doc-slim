# Benchmarks

`run_benchmarks.py` wraps `document-context-optimizer/scripts/benchmark.py`. It builds (or reuses) indexes for each case document, runs each question through retrieval, and reports both baselines:

- **Baseline A**: full document tokens x number of questions (repeated full-context workflow)
- **Baseline B**: full document once plus growing conversation overhead

All token figures come from the local estimator and are labeled as estimates, not exact API billing counts. Results are written to `results/` and `workspace/reports/benchmark-report.json`.

Run:
```
python benchmarks/run_benchmarks.py
```

Larger fixtures (75, 150, 300, 500-page synthetic documents and a scanned PDF) are on the roadmap for v0.2; current committed results reflect only the small synthetic fixtures in `tests/fixtures/`. Do not quote reduction percentages beyond what the committed reports show.
