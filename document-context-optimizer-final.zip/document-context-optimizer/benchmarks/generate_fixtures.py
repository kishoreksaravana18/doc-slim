#!/usr/bin/env python3
"""Generate a synthetic ~40-page annual-report PDF for benchmarking.

Entirely synthetic content; no copyrighted material. Regenerate any time with:
    python benchmarks/generate_fixtures.py
"""
from __future__ import annotations

import contextlib
import io
import random
from pathlib import Path

OUT = Path(__file__).resolve().parent.parent / "tests" / "fixtures" / "large-report.pdf"

SECTIONS = [
    ("Executive Summary", "The company delivered solid results with revenue growth of 8.9 percent in North America offset by a 3.4 percent decline in Europe driven by currency impact."),
    ("Methodology", "Figures are prepared under standard accounting policies with a December 31 reporting period, presented in United States dollars in millions."),
    ("Operating Results", "Operating margin declined by 120 basis points. Management attributes the decline primarily to elevated logistics costs and an unfavorable product mix, partially offset by pricing actions."),
    ("Regional Performance", "North America revenue rose to 463 million from 425 million. Europe revenue declined to 201 million from 208 million on foreign-exchange headwinds."),
    ("Risk Factors", "Market risks include demand volatility. Operational risks include supply chain disruption. Regulatory risks include changes to trade policy and data protection rules."),
    ("Financial Statements", "The income statement, balance sheet, and statement of cash flows follow, with detailed line items and comparative periods for the prior fiscal year."),
    ("Notes to Financial Statements", "Note 8 describes the components of cost of goods sold, including logistics costs which increased 14 percent year over year and materially affected gross margin."),
    ("Outlook", "For the coming year, management expects mid single digit revenue growth with gradual margin recovery as logistics costs normalize through the second half."),
]

SECTION_FILLER = {
    "Executive Summary": "Strategic priorities centered on customer expansion and portfolio simplification during the fiscal year under review. ",
    "Methodology": "Consolidation procedures, estimation techniques, and materiality thresholds were applied consistently with prior periods. ",
    "Operating Results": "Gross margin, operating margin, and segment profitability trends reflected input cost dynamics and mix effects. ",
    "Regional Performance": "Regional demand patterns across North America, Europe, and Asia Pacific varied with local market conditions. ",
    "Risk Factors": "Enterprise risk management processes identify, assess, and monitor exposures across market, credit, and compliance categories. ",
    "Financial Statements": "Line items include net sales, cost of sales, selling expenses, depreciation, amortization, and provision for taxes. ",
    "Notes to Financial Statements": "Disclosure requirements cover leases, pensions, contingencies, derivatives, and segment reconciliation detail. ",
    "Outlook": "Forward-looking guidance assumes stable macroeconomic conditions and gradual normalization of freight and warehousing expense. ",
}

PAGES_PER_SECTION = 18  # 8 sections x 18 pages = 144 pages


def main() -> int:
    with contextlib.redirect_stdout(io.StringIO()):
        import fitz

    random.seed(42)
    doc = fitz.open()
    for title, lead in SECTIONS:
        filler = SECTION_FILLER[title]
        for page_num in range(PAGES_PER_SECTION):
            page = doc.new_page()
            text = ""
            if page_num == 0:
                text += title.upper() + "\n\n" + lead + "\n\n"
            text += (filler * 14).strip()
            page.insert_textbox(fitz.Rect(72, 72, 540, 770), text, fontsize=10)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(OUT))
    doc.close()
    print(f"Wrote {OUT} ({len(SECTIONS) * PAGES_PER_SECTION} pages)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
