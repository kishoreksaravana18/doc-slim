#!/usr/bin/env python3
"""Run the benchmark suite and copy the report into benchmarks/results/."""
import shutil
import subprocess
import sys
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SCRIPT = ROOT / "document-context-optimizer" / "scripts" / "benchmark.py"
CASES = ROOT / "tests" / "evaluations" / "benchmark-cases.json"

def main() -> int:
    fixture = ROOT / "tests" / "fixtures" / "large-report.pdf"
    if not fixture.exists():
        subprocess.run([sys.executable, str(ROOT / "benchmarks" / "generate_fixtures.py")], check=True)
    result = subprocess.run(
        [sys.executable, str(SCRIPT), "--cases", str(CASES),
         "--workspace", str(ROOT / "workspace"), "--output", str(ROOT / "workspace" / "reports")],
        cwd=ROOT,
    )
    if result.returncode != 0:
        return result.returncode
    src = ROOT / "workspace" / "reports" / "benchmark-report.json"
    dst = ROOT / "benchmarks" / "results" / f"benchmark-{date.today().isoformat()}.json"
    if src.exists():
        shutil.copy(src, dst)
        print(f"Report copied to {dst}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
