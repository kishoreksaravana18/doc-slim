# Architecture

See `document-context-optimizer/references/architecture.md` for the canonical description. Summary:

```mermaid
flowchart LR
    A[Document] --> B[Inspection]
    B --> C[Extraction]
    C --> D[Semantic Chunking]
    D --> E[Local Index]
    Q[User Question] --> F[Retrieval]
    E --> F
    F --> G[Selected Evidence]
    G --> H[Claude Answer]
    H --> I[Compact Session Memory]
    I --> F
```

Two layers: the Agent Skill (SKILL.md plus references) governs Claude's behavior; the local Python engine performs extraction, chunking, BM25 indexing, budgeted retrieval, validation, and benchmarking. Everything runs locally with no hosted vector database and no required API key.
