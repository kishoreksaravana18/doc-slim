# Benchmarking

Method: `benchmark.py` indexes each case document, runs each question through retrieval, and computes both baselines.

- Baseline A = document_tokens x questions (full document per question)
- Baseline B = document once + per-follow-up overhead (prior answers ~400 tokens + ~10% of document as repeated working context)
- Optimized = document-map tokens + sum of retrieved tokens per question
- Reduction = (1 - optimized / baseline) x 100

Retrieval precision/recall are computed only for cases with labeled `expected_chunk_ids`. All token figures are local estimates.

Engineering targets (not achieved claims until the committed reports demonstrate them): median repeated-context reduction >= 70%, recall >= 90%, citation accuracy >= 95%, unsupported claim rate < 2%, 3-6 chunks per targeted question, index reuse >= 95% on follow-ups, quality loss vs full-context < 5%.
