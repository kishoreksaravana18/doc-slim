# Installation

## Prerequisites
Python 3.11 or later. No API key is required for core operation.

## macOS / Linux
```bash
git clone https://github.com/kishoresaravana/document-context-optimizer.git
cd document-context-optimizer
python3 -m venv .venv
source .venv/bin/activate
pip install -e .
```

## Windows (PowerShell)
```powershell
git clone https://github.com/kishoresaravana/document-context-optimizer.git
cd document-context-optimizer
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -e .
```

## Optional extras
```bash
pip install -e ".[ocr]"        # scanned-PDF OCR (also requires system tesseract:
                               #   macOS: brew install tesseract
                               #   Ubuntu: sudo apt install tesseract-ocr
                               #   Windows: https://github.com/UB-Mannheim/tesseract/wiki)
pip install -e ".[dev]"        # pytest, ruff, mypy, build
```

## Verify
```bash
pytest -q
doc-context --help
```

## Installing the Claude Agent Skill
The skill folder is `document-context-optimizer/` inside this repo (the one containing SKILL.md).

- **Claude Code**: copy or symlink the folder into your project's `.claude/skills/` directory (or your personal `~/.claude/skills/` directory):
  ```bash
  mkdir -p .claude/skills
  cp -r document-context-optimizer .claude/skills/document-context-optimizer
  ```
- **Claude.ai / Claude apps**: upload the skill folder (or a zip of it) through the Skills section in Settings > Capabilities, where available on your plan.

Skill installation locations can change between Claude releases; check the current Agent Skills documentation at https://docs.claude.com if the paths above do not match your version.
