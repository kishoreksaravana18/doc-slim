# Limitations

- This project does not control how a Claude interface initially processes an uploaded file. Its measurable benefit is in repeated downstream usage: reusable indexing, selective retrieval, and smaller context packages.
- Token counts are local estimates, not exact API billing values.
- Table extraction is heuristic; verify critical numbers against the cited page.
- OCR (optional) can misread names, numbers, and dates; OCR-derived citations are flagged.
- Lexical (BM25) retrieval can miss purely semantic matches; query expansion mitigates but does not eliminate this. Optional local embeddings are on the roadmap (v0.2).
- DOCX has no fixed page boundaries; citations use section headings.
- Multi-column PDF layouts may extract in uncertain order; this is reported, not silently fixed.
- Language handling is tuned for English in v0.1.
- Current benchmark fixtures are small synthetic documents; large-document results (75 to 500 pages) are pending (v0.2).
