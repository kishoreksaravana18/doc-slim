# Usage

## Quick start
```bash
doc-context inspect report.pdf
doc-context index report.pdf
doc-context search <document_id> "termination for convenience"
doc-context context <document_id> "termination for convenience"
doc-context validate <document_id>
doc-context clean <document_id>
```

## Script-level interface
```bash
python document-context-optimizer/scripts/inspect_document.py path/to/file.pdf
python document-context-optimizer/scripts/build_index.py path/to/file.pdf --output workspace
python document-context-optimizer/scripts/retrieve_chunks.py \
  --index workspace/indexes/DOCUMENT_ID/index.json \
  --query "What are the renewal terms?" --top-k 4 --max-tokens 7000
python document-context-optimizer/scripts/answer_context.py \
  --index workspace/indexes/DOCUMENT_ID/index.json \
  --query "What are the renewal terms?" --format markdown
python document-context-optimizer/scripts/benchmark.py \
  --cases tests/evaluations/benchmark-cases.json --output workspace/reports
```

## Typical Claude workflow
1. Inspect the uploaded file
2. Build or reuse the index (keyed by file hash)
3. Read the compact document map to orient
4. Retrieve per question within the token budget
5. Answer with page/section citations
6. Update compact session memory; follow-ups reuse the index

## Configuration
Copy `config.example.yaml` and pass values via CLI flags or environment variables. Key defaults: chunking 1,500/2,400/250/140 tokens; retrieval top-k 3, budgets 6,000/12,000 tokens, max 8 chunks; memory max 800 tokens.
