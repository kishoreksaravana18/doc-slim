# Example: annual report

**User:** "What caused operating margin to decline?"

Retrieve MD&A discussion plus the relevant footnote and any supporting table. Confirm reporting period, currency, and units before quoting numbers. Distinguish percent change from percentage-point change. For an executive summary, use hierarchical summarization (chunk -> section -> document) and cite page ranges for each key finding.
