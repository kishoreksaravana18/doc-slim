# Example: contract review

Use smaller chunks for contracts: `build_index.py contract.pdf --target-tokens 800 --max-tokens 1400`.
For each clause question, retrieve the clause plus definitions and cross-references. Preserve clause numbering exactly. Compare amendments against originals when a collection includes both, state the hierarchy, and note uncertainty. Provide analysis, not legal advice, and recommend professional review for consequential decisions.
