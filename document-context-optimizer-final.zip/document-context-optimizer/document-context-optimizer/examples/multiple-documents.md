# Example: multiple documents

**User:** "Compare the termination terms in these three agreements."

Build one index per file (each gets its own document_id by hash). Retrieve equivalent sections from each with per-document queries, apply fair top-k so one large document does not dominate, and answer with a per-document comparison table citing `[Supplier Agreement, Section 7.2]` style sources. Report contradictions; never silently discard older versions.
