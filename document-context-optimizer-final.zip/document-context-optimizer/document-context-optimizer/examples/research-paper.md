# Example: research paper

**User:** "What methodology did the authors use, and what limitations did they identify?"

Retrieve the Methodology, Results, Limitations sections and relevant appendices/footnotes; never answer from the abstract alone. Cite `[Pages 4-7, Methodology]` and `[Page 18, Limitations]`. If statistical details live in an appendix table, retrieve the table with its footnotes.
