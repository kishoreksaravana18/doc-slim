# Example: targeted question

**User:** "What does this 250-page contract say about termination for convenience?"

**Workflow:**
1. `python scripts/inspect_document.py contract.pdf` — confirms 250 pages, ~120k estimated tokens, searchable
2. `python scripts/build_index.py contract.pdf --output workspace` (or reuse if `existing_index_found`)
3. `python scripts/retrieve_chunks.py --index workspace/indexes/<id>/index.json --query "termination for convenience" --top-k 4`
4. Retrieval returns the termination clause, its defined terms, and one neighbor (cross-referenced notice section)
5. Answer with `## Answer / ## Evidence / ## Limitations`, citing `[Section 12.3, Termination]` and `[Section 1, Definitions]`
6. `python scripts/compact_memory.py workspace/memory/session.json --add-question "termination for convenience" --chunks DOC-...-C0018 --facts "Only the customer may terminate for convenience with 30 days written notice." --citations "Section 12.3"`
