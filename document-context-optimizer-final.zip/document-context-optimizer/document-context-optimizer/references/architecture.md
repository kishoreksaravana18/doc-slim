# Architecture

Pipeline: Document -> Inspection -> Extraction -> Semantic Chunking -> Local Index -> Retrieval -> Selected Evidence -> Claude Answer -> Compact Session Memory.

## Layers
- **Layer A (Agent Skill)**: SKILL.md tells Claude when to activate, how to run the scripts, how to cite, and how to keep memory compact.
- **Layer B (Local engine)**: pure-Python scripts under `scripts/` performing extraction, chunking, BM25 indexing, budgeted retrieval, validation, and benchmarking. No hosted vector database, no API key required.

## Storage layout (workspace/)
- `extracted/<doc_id>/extraction.json` — normalized pages, headings, tables
- `chunks/<doc_id>/C####.txt` — raw chunk text, one file per chunk
- `indexes/<doc_id>/index.json` — metadata + chunk records (paths only, never full text)
- `indexes/<doc_id>/document-map.md` — compact page-range map
- `memory/session.json` — compact session memory
- `reports/` — benchmark output

## Index reuse
The document ID is the first 6 hex chars of the file's SHA-256. Reuse requires: matching hash, matching schema version, matching chunking settings.
