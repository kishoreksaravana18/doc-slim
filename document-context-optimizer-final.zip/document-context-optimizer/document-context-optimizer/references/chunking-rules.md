# Chunking rules

Boundary preference order: document > chapter > major heading > subheading > numbered clause > paragraph group > table > page > fixed-size fallback.

Defaults (configurable): target 1,500 estimated tokens, max 2,400, min 250, overlap 140.

Never separate:
- A heading from its first paragraph
- A contract clause from its subclauses
- A table title from its table
- A warning from its procedure
- A definition from the defined term
- A numbered step from its supporting details

Use smaller chunks (target ~800) for contracts, regulations, policies, troubleshooting sections, and dense tables. Use larger chunks (target ~1,800) for narrative reports, books, transcripts, and general prose.

Chunk IDs are stable: `DOC-<doc_id>-C<index:04d>`. Each chunk records pages, section path, heading, type, token count, keywords, entities, dates, a one-sentence summary, neighbor links, and a content path. Raw text lives in separate files; the index JSON holds metadata only.
