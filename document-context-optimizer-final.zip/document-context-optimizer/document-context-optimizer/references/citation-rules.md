# Citation rules

Formats:
- `[Page 14, Financial Results]`
- `[Pages 22-23, Risk Factors]`
- `[Section 4.2, Payment Terms]`
- `[Table 7, Page 73]`
- `[Document B, Section 8.1]` for multi-document work

Rules:
1. Cite the actual supporting location, never an index summary.
2. Keep printed page numbers and internal PDF page indexes separate when they differ; cite the printed label.
3. Cite table footnotes when they materially qualify a number.
4. Never cite pages that were not retrieved and read.
5. Never state that the whole document was reviewed unless it was.
6. Mark OCR-derived citations: `[Page 12, OCR-uncertain]`.
7. Preserve clause numbers exactly as written.
8. For calculated results, cite the source values and show the calculation.
