# Retrieval rules

Staged pipeline:
1. **Metadata filtering** — document, page, section, heading, chunk type, date, entity, table status
2. **Lexical retrieval** — BM25 over chunk text with heading and keyword boosting
3. **Reranking** — bonuses for heading match, exact phrase, entity match, date match, clause-number match, table priority
4. **Deduplication** — drop chunks whose token sets overlap a higher-ranked chunk by >= 85%
5. **Budgeted selection** — top-k 3 default, 6,000-token initial budget, 12,000 expanded, max 8 chunks; always keep at least one complete high-confidence chunk; report excluded high scorers
6. **Conditional neighbor expansion** — only for chunks that start mid-thought, end mid-sentence, reference nearby definitions, or are tables missing their title/footnote

Query rewriting: expand the user's question into a bounded set of variants using the local synonym table (retrieval-time only; never shown to the user). For legal documents add defined terms, clause references, notice/survival vocabulary. For financial reports add metric synonyms, periods, units, segment names.

Evidence sufficiency: classify high / moderate / low / not found. When weak: broaden terms, search headings, search exact phrases, pull neighbors, follow cross-references, check tables and footnotes, and if still unresolved, say the document does not clearly answer.

Semantic embeddings are an optional extra (`pip install "document-context-optimizer[semantic]"` in a future release); the system always falls back to lexical retrieval and never downloads models silently.
