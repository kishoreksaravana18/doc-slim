# Token measurement

Estimator: local heuristic blending chars/4 and words*1.33 (`common/token_utils.py`). Always label figures as estimates; they are not exact API billing counts. An optional Anthropic token-counting API integration is planned (v0.3) and will be labeled as exact where used.

Reduction formula:
```
context_reduction_percentage = (1 - optimized_input_tokens / baseline_input_tokens) * 100
```

Two baselines, both always reported by `benchmark.py`:
- **Baseline A**: full document per question = document_tokens x questions
- **Baseline B**: full document once plus growing conversation (prior answers ~400 tokens each plus ~10% of document as repeated working context per follow-up)

Never pick whichever baseline flatters the result; show both. Also report indexing cost, retrieval overhead, memory overhead, question count, and average retrieved tokens per question.

Configurable defaults (`config.example.yaml`): activation at 15 pages / 8,000 tokens; chunking 1,500/2,400/250/140; retrieval top-k 3, budgets 6,000/12,000, max 8 chunks; memory max 800 tokens.
