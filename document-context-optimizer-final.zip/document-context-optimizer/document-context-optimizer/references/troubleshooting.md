# Troubleshooting

| Failure | Likely cause | Safe next action |
|---|---|---|
| `File not found` | Wrong path | Verify the path; list the uploads directory |
| `Unsupported extension` | Format not in v0.1 scope | Convert to PDF/DOCX/TXT/MD/HTML |
| `PDF is password protected` | Encrypted source | Ask the user for an unlocked copy; never bypass |
| `Could not open PDF` | Corrupt file | Ask for a re-export; partial extraction is not attempted on corrupt files |
| Pages flagged scanned, OCR unavailable | pytesseract not installed | `pip install "document-context-optimizer[ocr]"` plus system tesseract, or proceed with searchable pages only and say which pages were skipped |
| `No chunks matched the query` (exit 2) | Vocabulary mismatch | Broaden terms, check the document map, filter by section |
| `Index not found` | Never indexed, or workspace differs | Run `build_index.py`; confirm `--workspace` |
| Validation failed: missing chunk files | Workspace partially deleted | Rebuild with `--force` |
| Retrieval budget too small | max-tokens below one chunk | Raise `--max-tokens`; at least one complete chunk is always kept |
| Multiple ambiguous documents | Follow-up doesn't name the doc | Ask the user which document they mean |

Every error message states what failed, why it likely failed, what was and was not processed, and the safe next step. Partial failure is always reported, never hidden.
