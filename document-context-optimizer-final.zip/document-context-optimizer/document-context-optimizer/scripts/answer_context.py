#!/usr/bin/env python3
"""Produce a compact evidence package for Claude to answer from.

This does not generate the final answer; it assembles only the retrieved
evidence, source map, and retrieval notes in Markdown or JSON.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))
from retrieve_chunks import DEFAULT_MAX_TOKENS, DEFAULT_TOP_K, retrieve  # noqa: E402


def format_markdown(result: dict[str, Any]) -> str:
    lines = [f"# Query\n{result['query']}", "", "# Retrieved evidence"]
    for i, r in enumerate(result["retrieved"], 1):
        pages = (
            f"Page {r['page_start']}"
            if r["page_start"] == r["page_end"]
            else f"Pages {r['page_start']}-{r['page_end']}"
        )
        heading = r["heading"] or "Untitled section"
        lines.append(f"\n## Source {i} — {pages} — {heading}")
        lines.append(r["text"])
    lines.append("\n# Source map")
    for i, r in enumerate(result["retrieved"], 1):
        lines.append(f"- Source {i}: `{r['chunk_id']}`")
    lines.append("\n# Retrieval notes")
    lines.append(f"- {len(result['retrieved'])} chunk(s) retrieved.")
    for note in result["neighbor_notes"]:
        lines.append(f"- {note}")
    if result["excluded_high_scoring"]:
        excluded = ", ".join(e["chunk_id"] for e in result["excluded_high_scoring"])
        lines.append(f"- Excluded high-scoring chunks (budget): {excluded}")
    lines.append(f"- Estimated context size: {result['estimated_context_tokens']} tokens (local estimate).")
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Build a compact answer-context package.")
    parser.add_argument("--index", type=Path, required=True)
    parser.add_argument("--query", required=True)
    parser.add_argument("--top-k", type=int, default=DEFAULT_TOP_K)
    parser.add_argument("--max-tokens", type=int, default=DEFAULT_MAX_TOKENS)
    parser.add_argument("--format", choices=["markdown", "json"], default="markdown")
    args = parser.parse_args()
    if not args.index.exists():
        print(f"Index not found: {args.index}. Run build_index.py first.", file=sys.stderr)
        return 1
    try:
        result = retrieve(args.index, args.query, top_k=args.top_k, max_tokens=args.max_tokens)
    except Exception as exc:
        print(f"Failed to build context: {exc}", file=sys.stderr)
        return 1
    if args.format == "json":
        print(json.dumps(result, indent=2))
    else:
        print(format_markdown(result))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
