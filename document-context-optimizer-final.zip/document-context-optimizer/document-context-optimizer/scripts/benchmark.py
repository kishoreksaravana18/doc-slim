#!/usr/bin/env python3
"""Benchmark repeated-context reduction against defined baselines.

Baseline A: full document per question (document_tokens * questions).
Baseline B: full document once plus growing conversation overhead.
Optimized: indexing map cost plus retrieved context per question.

All token figures are local estimates and are labeled as such.
"""
from __future__ import annotations

import argparse
import json
import statistics
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from build_index import build_index  # noqa: E402
from common.token_utils import ESTIMATOR_NAME, context_reduction_percentage, estimate_tokens  # noqa: E402
from retrieve_chunks import retrieve  # noqa: E402


def run_benchmark(cases_path: Path, workspace: Path, output_dir: Path) -> dict:
    cases = json.loads(cases_path.read_text(encoding="utf-8"))
    reports = []
    for case in cases:
        doc_path = Path(case["document"])
        if not doc_path.exists():
            reports.append({"case_id": case.get("case_id"), "error": f"missing fixture {doc_path}"})
            continue
        t0 = time.time()
        index_path, reused = build_index(doc_path, workspace)
        indexing_seconds = time.time() - t0
        index_data = json.loads(index_path.read_text(encoding="utf-8"))
        doc_tokens = index_data["metadata"]["estimated_source_tokens"]
        map_tokens = estimate_tokens(Path(index_data["document_map_path"]).read_text(encoding="utf-8"))

        questions = case.get("questions", [])
        per_question = []
        precision_vals, recall_vals = [], []
        for q in questions:
            result = retrieve(index_path, q["query"], top_k=q.get("top_k", 3))
            retrieved_ids = {r["chunk_id"] for r in result["retrieved"]}
            retrieved_tokens = sum(r["token_count"] for r in result["retrieved"])
            per_question.append({
                "query": q["query"],
                "retrieved_chunks": len(retrieved_ids),
                "retrieved_tokens": retrieved_tokens,
                "latency_seconds": result["retrieval_latency_seconds"],
            })
            expected = set(q.get("expected_chunk_ids", []))
            if expected:
                hit = len(retrieved_ids & expected)
                precision_vals.append(hit / max(1, len(retrieved_ids)))
                recall_vals.append(hit / len(expected))

        n_q = max(1, len(questions))
        baseline_a = doc_tokens * n_q
        # Baseline B: document once plus per-question conversational overhead
        # (prior answers ~400 tokens each plus repeated working context ~10% of doc).
        baseline_b = doc_tokens + sum(400 + int(doc_tokens * 0.1) for _ in range(max(0, n_q - 1)))
        optimized = map_tokens + sum(pq["retrieved_tokens"] for pq in per_question)

        reports.append({
            "case_id": case.get("case_id"),
            "document": str(doc_path),
            "document_estimated_tokens": doc_tokens,
            "questions": n_q,
            "index_reused": reused,
            "indexing_latency_seconds": round(indexing_seconds, 3),
            "baseline_a_full_doc_per_question_tokens": baseline_a,
            "baseline_b_full_doc_plus_conversation_tokens": baseline_b,
            "optimized_input_tokens": optimized,
            "reduction_vs_baseline_a_percent": round(context_reduction_percentage(baseline_a, optimized), 2),
            "reduction_vs_baseline_b_percent": round(context_reduction_percentage(baseline_b, optimized), 2),
            "average_retrieved_tokens": round(statistics.mean(pq["retrieved_tokens"] for pq in per_question), 1) if per_question else 0,
            "average_chunks_retrieved": round(statistics.mean(pq["retrieved_chunks"] for pq in per_question), 1) if per_question else 0,
            "retrieval_precision": round(statistics.mean(precision_vals), 3) if precision_vals else None,
            "retrieval_recall": round(statistics.mean(recall_vals), 3) if recall_vals else None,
            "per_question": per_question,
        })

    summary = {
        "tokenizer": ESTIMATOR_NAME,
        "note": "All token figures are local estimates, not exact API billing counts.",
        "cases": reports,
    }
    output_dir.mkdir(parents=True, exist_ok=True)
    out_path = output_dir / "benchmark-report.json"
    out_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return summary


def main() -> int:
    parser = argparse.ArgumentParser(description="Run token-reduction benchmarks.")
    parser.add_argument("--cases", type=Path, required=True)
    parser.add_argument("--workspace", type=Path, default=Path("workspace"))
    parser.add_argument("--output", type=Path, default=Path("workspace/reports"))
    args = parser.parse_args()
    if not args.cases.exists():
        print(f"Cases file not found: {args.cases}", file=sys.stderr)
        return 1
    summary = run_benchmark(args.cases, args.workspace, args.output)
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
