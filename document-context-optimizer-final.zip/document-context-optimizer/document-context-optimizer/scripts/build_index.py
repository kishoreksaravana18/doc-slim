#!/usr/bin/env python3
"""Build (or reuse) a local searchable index for a document.

Workflow: hash -> reuse check -> extract -> chunk -> index -> document map.
Raw chunk text is stored in separate files; the index JSON holds metadata
and paths only.
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))
from chunk_document import (  # noqa: E402
    DEFAULT_MAX_TOKENS,
    DEFAULT_MIN_TOKENS,
    DEFAULT_OVERLAP_TOKENS,
    DEFAULT_TARGET_TOKENS,
    chunk_document,
)
from common.file_utils import document_id_from_hash, sha256_file, validate_input_file  # noqa: E402
from common.logging_utils import get_logger  # noqa: E402
from common.models import SCHEMA_VERSION, IndexMetadata  # noqa: E402
from common.token_utils import ESTIMATOR_NAME, estimate_tokens  # noqa: E402
from extract_document import extract_document  # noqa: E402

log = get_logger("index")


def build_document_map(extraction: dict[str, Any], chunks: list[Any], max_tokens: int = 1500) -> str:
    """Compact page-range map of major sections. No raw content."""
    lines = ["# Document map", f"Source: {extraction['source_file']}"]
    seen: set[str] = set()
    for c in chunks:
        heading = c.heading or "(untitled section)"
        if heading in seen:
            continue
        seen.add(heading)
        pages = f"Page {c.page_start}" if c.page_start == c.page_end else f"Pages {c.page_start}-{c.page_end}"
        lines.append(f"- {pages}: {heading} — {c.summary}")
        if estimate_tokens("\n".join(lines)) > max_tokens:
            lines.append("- (map truncated to stay compact)")
            break
    tables = extraction.get("tables", [])
    if tables:
        lines.append(f"- Tables detected: {len(tables)} (pages: {sorted({t['page'] for t in tables})})")
    return "\n".join(lines)


def build_index(
    file_path: Path,
    workspace: Path,
    target_tokens: int = DEFAULT_TARGET_TOKENS,
    max_tokens: int = DEFAULT_MAX_TOKENS,
    min_tokens: int = DEFAULT_MIN_TOKENS,
    overlap_tokens: int = DEFAULT_OVERLAP_TOKENS,
    force: bool = False,
    ocr: str = "auto",
) -> tuple[Path, bool]:
    """Build or reuse an index. Returns (index_path, reused)."""
    validate_input_file(file_path)
    file_hash = sha256_file(file_path)
    doc_id = document_id_from_hash(file_hash)
    index_dir = workspace / "indexes" / doc_id
    index_path = index_dir / "index.json"
    chunking_settings = {
        "target_tokens": target_tokens,
        "max_tokens": max_tokens,
        "min_tokens": min_tokens,
        "overlap_tokens": overlap_tokens,
    }

    if index_path.exists() and not force:
        try:
            existing = json.loads(index_path.read_text(encoding="utf-8"))
            meta = existing.get("metadata", {})
            if (
                meta.get("document_hash") == file_hash
                and meta.get("schema_version") == SCHEMA_VERSION
                and meta.get("chunking_settings") == chunking_settings
            ):
                log.info("Index reuse: cache hit for %s (%s)", file_path.name, doc_id)
                return index_path, True
            log.info("Index exists but settings/schema differ; rebuilding.")
        except (json.JSONDecodeError, OSError):
            log.warning("Existing index is corrupt; rebuilding.")

    extraction = extract_document(file_path, ocr=ocr)
    extracted_dir = workspace / "extracted" / doc_id
    extracted_dir.mkdir(parents=True, exist_ok=True)
    (extracted_dir / "extraction.json").write_text(json.dumps(extraction, indent=2), encoding="utf-8")

    chunks_dir = workspace / "chunks" / doc_id
    chunks = chunk_document(
        extraction, doc_id, chunks_dir,
        target_tokens=target_tokens, max_tokens=max_tokens,
        min_tokens=min_tokens, overlap_tokens=overlap_tokens,
    )

    source_tokens = estimate_tokens("\n".join(p["text"] for p in extraction["pages"]))
    metadata = IndexMetadata(
        schema_version=SCHEMA_VERSION,
        document_id=doc_id,
        document_hash=file_hash,
        source_file=file_path.name,
        created_at=datetime.now(timezone.utc).isoformat(),
        extraction_engine="document-context-optimizer/extract_document",
        chunking_settings=chunking_settings,
        tokenizer=ESTIMATOR_NAME,
        ocr_used=any("OCR applied" in w for w in extraction.get("warnings", [])),
        page_count=len(extraction["pages"]),
        estimated_source_tokens=source_tokens,
        chunk_count=len(chunks),
    )

    doc_map = build_document_map(extraction, chunks)
    index_dir.mkdir(parents=True, exist_ok=True)
    map_path = index_dir / "document-map.md"
    map_path.write_text(doc_map, encoding="utf-8")

    index_data = {
        "metadata": metadata.to_dict(),
        "document_map_path": str(map_path),
        "chunks": [c.to_dict() for c in chunks],
    }
    index_path.write_text(json.dumps(index_data, indent=2), encoding="utf-8")
    log.info("Indexed %s: %d chunks, ~%d source tokens", file_path.name, len(chunks), source_tokens)
    return index_path, False


def main() -> int:
    parser = argparse.ArgumentParser(description="Build a reusable local index for a document.")
    parser.add_argument("file", type=Path)
    parser.add_argument("--output", type=Path, default=Path("workspace"), help="Workspace directory")
    parser.add_argument("--target-tokens", type=int, default=DEFAULT_TARGET_TOKENS)
    parser.add_argument("--max-tokens", type=int, default=DEFAULT_MAX_TOKENS)
    parser.add_argument("--min-tokens", type=int, default=DEFAULT_MIN_TOKENS)
    parser.add_argument("--overlap-tokens", type=int, default=DEFAULT_OVERLAP_TOKENS)
    parser.add_argument("--force", action="store_true", help="Rebuild even if a matching index exists")
    parser.add_argument("--ocr", choices=["auto", "off"], default="auto")
    args = parser.parse_args()

    workspace = args.output if args.output.name == "workspace" or args.output.exists() else args.output
    if workspace.name == "indexes":
        workspace = workspace.parent
    try:
        index_path, reused = build_index(
            args.file, workspace,
            target_tokens=args.target_tokens, max_tokens=args.max_tokens,
            min_tokens=args.min_tokens, overlap_tokens=args.overlap_tokens,
            force=args.force, ocr=args.ocr,
        )
    except Exception as exc:
        print(f"Indexing failed: {exc}", file=sys.stderr)
        return 1
    data = json.loads(index_path.read_text(encoding="utf-8"))
    meta = data["metadata"]
    print(json.dumps({
        "index_path": str(index_path),
        "reused_existing_index": reused,
        "document_id": meta["document_id"],
        "chunks": meta["chunk_count"],
        "pages": meta["page_count"],
        "estimated_source_tokens": meta["estimated_source_tokens"],
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
