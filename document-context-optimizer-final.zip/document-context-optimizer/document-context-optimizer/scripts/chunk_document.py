#!/usr/bin/env python3
"""Semantic chunking of extracted documents.

Prefers structural boundaries (headings, clauses, paragraphs, tables,
pages) over fixed character splits. Keeps headings with their first
paragraph, keeps tables whole, and links neighboring chunks.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common.models import Chunk  # noqa: E402
from common.text_utils import (  # noqa: E402
    extract_dates,
    extract_entities,
    extract_keywords,
    first_sentence,
    is_probable_heading,
)
from common.token_utils import estimate_tokens  # noqa: E402

DEFAULT_TARGET_TOKENS = 1500
DEFAULT_MAX_TOKENS = 2400
DEFAULT_MIN_TOKENS = 250
DEFAULT_OVERLAP_TOKENS = 140


def _split_blocks(pages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Split page text into blocks: headings, paragraphs, list groups."""
    blocks: list[dict[str, Any]] = []
    for page in pages:
        current: list[str] = []
        for line in page["text"].splitlines():
            if is_probable_heading(line):
                if current:
                    blocks.append({"type": "prose", "text": "\n".join(current).strip(), "page": page["page"]})
                    current = []
                blocks.append({"type": "heading", "text": line.strip().lstrip("#").strip(), "page": page["page"]})
            elif not line.strip():
                if current:
                    blocks.append({"type": "prose", "text": "\n".join(current).strip(), "page": page["page"]})
                    current = []
            else:
                current.append(line)
        if current:
            blocks.append({"type": "prose", "text": "\n".join(current).strip(), "page": page["page"]})
    return [b for b in blocks if b["text"]]


def chunk_document(
    extraction: dict[str, Any],
    document_id: str,
    chunks_dir: Path,
    target_tokens: int = DEFAULT_TARGET_TOKENS,
    max_tokens: int = DEFAULT_MAX_TOKENS,
    min_tokens: int = DEFAULT_MIN_TOKENS,
    overlap_tokens: int = DEFAULT_OVERLAP_TOKENS,
) -> list[Chunk]:
    """Chunk an extraction result and write raw chunk text files."""
    chunks_dir.mkdir(parents=True, exist_ok=True)
    blocks = _split_blocks(extraction["pages"])

    # Tables become their own blocks, kept whole.
    for table in extraction.get("tables", []):
        blocks.append({"type": "table", "text": table["markdown"], "page": table["page"]})
    blocks.sort(key=lambda b: b["page"])

    chunks: list[Chunk] = []
    buffer: list[dict[str, Any]] = []
    buffer_tokens = 0
    section_path: list[str] = []
    pending_heading: str | None = None

    def flush(force: bool = False) -> None:
        nonlocal buffer, buffer_tokens
        if not buffer:
            return
        if not force and buffer_tokens < min_tokens:
            return
        text = "\n\n".join(b["text"] for b in buffer)
        page_start = min(b["page"] for b in buffer)
        page_end = max(b["page"] for b in buffer)
        chunk_type = "table" if any(b["type"] == "table" for b in buffer) else "prose"
        idx = len(chunks)
        chunk_id = f"DOC-{document_id}-C{idx:04d}"
        content_path = chunks_dir / f"C{idx:04d}.txt"
        content_path.write_text(text, encoding="utf-8")
        chunks.append(
            Chunk(
                chunk_id=chunk_id,
                document_id=document_id,
                source_file=extraction["source_file"],
                page_start=page_start,
                page_end=page_end,
                section_path=list(section_path),
                heading=section_path[-1] if section_path else "",
                chunk_type=chunk_type,
                token_count=estimate_tokens(text),
                character_count=len(text),
                keywords=extract_keywords(text),
                entities=extract_entities(text),
                dates=extract_dates(text),
                summary=first_sentence(text),
                previous_chunk_id=None,
                next_chunk_id=None,
                content_path=str(content_path),
            )
        )
        # Overlap: retain the tail of the flushed buffer as context for the next chunk.
        tail = text[-overlap_tokens * 4 :]
        buffer = [{"type": "prose", "text": tail, "page": page_end}] if tail and not force else []
        buffer_tokens = estimate_tokens(tail) if buffer else 0

    for block in blocks:
        block_tokens = estimate_tokens(block["text"])
        if block["type"] == "heading":
            # A heading starts a new section; flush the previous section if large enough.
            if buffer_tokens >= min_tokens:
                flush(force=True)
            section_path = section_path[:0] + [block["text"]]
            pending_heading = block["text"]
            buffer.append(block)
            buffer_tokens += block_tokens
            continue
        # Never separate a heading from its first paragraph: heading stays buffered.
        if block["type"] == "table" and block_tokens > max_tokens:
            # Oversized table: flush current buffer, then emit table alone.
            flush(force=True)
            buffer = [block]
            buffer_tokens = block_tokens
            flush(force=True)
            buffer, buffer_tokens = [], 0
            continue
        if buffer_tokens + block_tokens > max_tokens and buffer_tokens >= min_tokens:
            flush(force=True)
        if block_tokens > max_tokens:
            # Fixed-size fallback for a single oversized block.
            words = block["text"].split()
            step = max(50, int(target_tokens / 1.33))
            for i in range(0, len(words), step):
                part = " ".join(words[i : i + step])
                buffer.append({"type": "prose", "text": part, "page": block["page"]})
                buffer_tokens += estimate_tokens(part)
                if buffer_tokens >= target_tokens:
                    flush(force=True)
        else:
            buffer.append(block)
            buffer_tokens += block_tokens
            if buffer_tokens >= target_tokens:
                flush(force=True)
        pending_heading = None
    _ = pending_heading
    flush(force=True)

    # Link neighbors.
    for i, c in enumerate(chunks):
        c.previous_chunk_id = chunks[i - 1].chunk_id if i > 0 else None
        c.next_chunk_id = chunks[i + 1].chunk_id if i < len(chunks) - 1 else None
    return chunks


def main() -> int:
    parser = argparse.ArgumentParser(description="Chunk an extracted document (JSON from extract_document.py).")
    parser.add_argument("extraction_json", type=Path)
    parser.add_argument("--document-id", required=True)
    parser.add_argument("--chunks-dir", type=Path, required=True)
    parser.add_argument("--target-tokens", type=int, default=DEFAULT_TARGET_TOKENS)
    parser.add_argument("--max-tokens", type=int, default=DEFAULT_MAX_TOKENS)
    parser.add_argument("--min-tokens", type=int, default=DEFAULT_MIN_TOKENS)
    parser.add_argument("--overlap-tokens", type=int, default=DEFAULT_OVERLAP_TOKENS)
    args = parser.parse_args()
    try:
        extraction = json.loads(args.extraction_json.read_text(encoding="utf-8"))
        chunks = chunk_document(
            extraction,
            args.document_id,
            args.chunks_dir,
            target_tokens=args.target_tokens,
            max_tokens=args.max_tokens,
            min_tokens=args.min_tokens,
            overlap_tokens=args.overlap_tokens,
        )
    except Exception as exc:
        print(f"Chunking failed: {exc}", file=sys.stderr)
        return 1
    print(json.dumps([c.to_dict() for c in chunks], indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


_ = re  # keep import for future clause-aware splitting extensions
