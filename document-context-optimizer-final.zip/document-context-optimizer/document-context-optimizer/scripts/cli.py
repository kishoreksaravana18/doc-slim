#!/usr/bin/env python3
"""Unified CLI: doc-context inspect | index | search | context | benchmark | validate | clean."""
from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

DEFAULT_WORKSPACE = Path("workspace")


def _index_path(workspace: Path, document_id: str) -> Path:
    return workspace / "indexes" / document_id / "index.json"


def cmd_inspect(args: argparse.Namespace) -> int:
    from inspect_document import inspect_document
    result = inspect_document(Path(args.file), workspace=args.workspace)
    print(json.dumps(result.to_dict(), indent=2))
    return 0


def cmd_index(args: argparse.Namespace) -> int:
    from build_index import build_index
    index_path, reused = build_index(Path(args.file), args.workspace, force=args.force)
    data = json.loads(index_path.read_text(encoding="utf-8"))
    print(json.dumps({
        "index_path": str(index_path),
        "reused_existing_index": reused,
        "document_id": data["metadata"]["document_id"],
        "chunks": data["metadata"]["chunk_count"],
    }, indent=2))
    return 0


def cmd_search(args: argparse.Namespace) -> int:
    from retrieve_chunks import retrieve
    index = _index_path(args.workspace, args.document_id)
    if not index.exists():
        print(f"No index for document {args.document_id}. Run: doc-context index <file>", file=sys.stderr)
        return 1
    result = retrieve(index, args.query, top_k=args.top_k, max_tokens=args.max_tokens)
    if args.quiet:
        for r in result["retrieved"]:
            print(r["chunk_id"])
    else:
        print(json.dumps(result, indent=2))
    return 0 if result["retrieved"] else 2


def cmd_context(args: argparse.Namespace) -> int:
    from answer_context import format_markdown
    from retrieve_chunks import retrieve
    index = _index_path(args.workspace, args.document_id)
    if not index.exists():
        print(f"No index for document {args.document_id}.", file=sys.stderr)
        return 1
    result = retrieve(index, args.query, top_k=args.top_k, max_tokens=args.max_tokens)
    print(json.dumps(result, indent=2) if args.json else format_markdown(result))
    return 0


def cmd_benchmark(args: argparse.Namespace) -> int:
    from benchmark import run_benchmark
    summary = run_benchmark(Path(args.cases), args.workspace, args.workspace / "reports")
    print(json.dumps(summary, indent=2))
    return 0


def cmd_validate(args: argparse.Namespace) -> int:
    from validate_index import validate_index
    index = _index_path(args.workspace, args.document_id)
    ok, errors, stats = validate_index(index, workspace=args.workspace)
    if ok:
        print(f"Validation passed ({stats['chunks']} chunks).")
        return 0
    for e in errors:
        print(f"- {e}", file=sys.stderr)
    return 1


def cmd_clean(args: argparse.Namespace) -> int:
    doc_id = args.document_id
    targets = [
        args.workspace / "indexes" / doc_id,
        args.workspace / "chunks" / doc_id,
        args.workspace / "extracted" / doc_id,
        args.workspace / "memory" / doc_id,
        args.workspace / "reports" / doc_id,
    ]
    existing = [t for t in targets if t.exists()]
    if not existing:
        print(f"Nothing to clean for document {doc_id}.")
        return 0
    if not args.force:
        print("This will delete:")
        for t in existing:
            print(f"  {t}")
        answer = input("Proceed? [y/N] ").strip().lower()
        if answer != "y":
            print("Cancelled.")
            return 0
    for t in existing:
        shutil.rmtree(t)
    print(f"Removed {len(existing)} director(ies) for document {doc_id}.")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(prog="doc-context", description="Local document context optimizer.")
    parser.add_argument("--workspace", type=Path, default=DEFAULT_WORKSPACE)
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("inspect", help="Inspect a document before processing")
    p.add_argument("file")
    p.set_defaults(func=cmd_inspect)

    p = sub.add_parser("index", help="Build or reuse a local index")
    p.add_argument("file")
    p.add_argument("--force", action="store_true")
    p.set_defaults(func=cmd_index)

    p = sub.add_parser("search", help="Search an indexed document")
    p.add_argument("document_id")
    p.add_argument("query")
    p.add_argument("--top-k", type=int, default=3)
    p.add_argument("--max-tokens", type=int, default=6000)
    p.add_argument("--quiet", action="store_true")
    p.set_defaults(func=cmd_search)

    p = sub.add_parser("context", help="Build a compact answer-context package")
    p.add_argument("document_id")
    p.add_argument("query")
    p.add_argument("--top-k", type=int, default=3)
    p.add_argument("--max-tokens", type=int, default=6000)
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_context)

    p = sub.add_parser("benchmark", help="Run benchmark cases")
    p.add_argument("--cases", default="tests/evaluations/benchmark-cases.json")
    p.set_defaults(func=cmd_benchmark)

    p = sub.add_parser("validate", help="Validate an index")
    p.add_argument("document_id")
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("clean", help="Remove all workspace data for a document")
    p.add_argument("document_id")
    p.add_argument("--force", action="store_true")
    p.set_defaults(func=cmd_clean)

    args = parser.parse_args()
    try:
        return args.func(args)
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
