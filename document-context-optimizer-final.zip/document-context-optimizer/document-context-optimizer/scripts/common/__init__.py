"""Shared utilities for the document-context-optimizer scripts."""
