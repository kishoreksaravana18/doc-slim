"""File utilities: hashing, safe path handling, size limits."""
from __future__ import annotations

import hashlib
import re
from pathlib import Path

MAX_FILE_SIZE_BYTES = 200 * 1024 * 1024  # 200 MB default limit
SUPPORTED_EXTENSIONS = {".pdf", ".docx", ".txt", ".md", ".markdown", ".html", ".htm"}


class UnsupportedFormatError(ValueError):
    """Raised when a file format is not supported."""


class FileTooLargeError(ValueError):
    """Raised when a file exceeds the configured size limit."""


class UnsafePathError(ValueError):
    """Raised when a path escapes the allowed workspace."""


def sha256_file(path: Path) -> str:
    """Return the SHA-256 hex digest of a file, streamed in blocks."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(65536), b""):
            h.update(block)
    return h.hexdigest()


def document_id_from_hash(file_hash: str) -> str:
    """Short stable document ID derived from the file hash."""
    return file_hash[:6]


def sanitize_filename(name: str) -> str:
    """Strip path separators and control characters from a filename."""
    name = Path(name).name  # drops any directory components
    name = re.sub(r"[\x00-\x1f\\/:*?\"<>|]", "_", name)
    name = name.strip(". ")
    return name or "unnamed"


def ensure_within(base: Path, candidate: Path) -> Path:
    """Resolve candidate and verify it stays inside base. Raises UnsafePathError."""
    base_resolved = base.resolve()
    resolved = candidate.resolve()
    if base_resolved != resolved and base_resolved not in resolved.parents:
        raise UnsafePathError(f"Path escapes workspace: {candidate}")
    return resolved


def validate_input_file(path: Path, max_bytes: int = MAX_FILE_SIZE_BYTES) -> None:
    """Validate that an input file exists, is supported, and is within size limits."""
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")
    if not path.is_file():
        raise UnsupportedFormatError(f"Not a regular file: {path}")
    if path.suffix.lower() not in SUPPORTED_EXTENSIONS:
        raise UnsupportedFormatError(
            f"Unsupported extension '{path.suffix}'. "
            f"Supported: {', '.join(sorted(SUPPORTED_EXTENSIONS))}"
        )
    size = path.stat().st_size
    if size == 0:
        raise ValueError(f"File is empty: {path}")
    if size > max_bytes:
        raise FileTooLargeError(
            f"File is {size} bytes; limit is {max_bytes} bytes. "
            "Raise the limit explicitly if this is intentional."
        )
