"""Structured logging with secret redaction. Full document text is never logged."""
from __future__ import annotations

import logging
import re

SECRET_PATTERNS = [
    re.compile(r"(sk-[a-zA-Z0-9\-_]{8,})"),
    re.compile(r"((?:api[_-]?key|token|password|secret|authorization)\s*[:=]\s*)(\S+)", re.I),
    re.compile(r"(Bearer\s+)[A-Za-z0-9\-._~+/]+=*", re.I),
]


def redact(message: str) -> str:
    """Replace likely secrets in a log message with [REDACTED]."""
    out = message
    out = SECRET_PATTERNS[0].sub("[REDACTED]", out)
    out = SECRET_PATTERNS[1].sub(r"\1[REDACTED]", out)
    out = SECRET_PATTERNS[2].sub(r"\1[REDACTED]", out)
    return out


class RedactingFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        return redact(super().format(record))


def get_logger(name: str, level: str = "INFO") -> logging.Logger:
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(
            RedactingFormatter("%(asctime)s %(levelname)s %(name)s %(message)s")
        )
        logger.addHandler(handler)
    logger.setLevel(getattr(logging, level.upper(), logging.INFO))
    return logger
