"""Data models for document-context-optimizer."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

SCHEMA_VERSION = "1.0"


@dataclass
class InspectionResult:
    document_id: str
    file_name: str
    file_type: str
    file_size_bytes: int
    page_count: int
    character_count: int
    estimated_tokens: int
    searchable: bool
    ocr_required: bool
    language: str
    headings_detected: bool
    tables_detected: int
    existing_index_found: bool
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class Chunk:
    chunk_id: str
    document_id: str
    source_file: str
    page_start: int
    page_end: int
    section_path: list[str]
    heading: str
    chunk_type: str  # prose | table | heading | list
    token_count: int
    character_count: int
    keywords: list[str]
    entities: list[str]
    dates: list[str]
    summary: str
    previous_chunk_id: str | None
    next_chunk_id: str | None
    content_path: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class IndexMetadata:
    schema_version: str
    document_id: str
    document_hash: str
    source_file: str
    created_at: str
    extraction_engine: str
    chunking_settings: dict[str, Any]
    tokenizer: str
    ocr_used: bool
    page_count: int
    estimated_source_tokens: int
    chunk_count: int

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
