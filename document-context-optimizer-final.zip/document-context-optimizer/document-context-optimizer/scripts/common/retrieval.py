"""Local lexical retrieval: BM25 ranking with metadata filtering,
query expansion, token-aware budget selection, deduplication, and
conditional neighbor expansion. No external services required.
"""
from __future__ import annotations

import math
import re
from collections import Counter
from dataclasses import dataclass, field
from typing import Any

from .text_utils import tokenize

BM25_K1 = 1.5
BM25_B = 0.75

# Small local synonym table used only for retrieval-time query expansion.
QUERY_EXPANSIONS: dict[str, list[str]] = {
    "terminate": ["termination", "terminated", "cancel", "cancellation", "exit"],
    "termination": ["terminate", "cancel", "cancellation", "convenience"],
    "renewal": ["renew", "extension", "extend", "expiration", "expire"],
    "notice": ["notify", "notification", "written"],
    "revenue": ["sales", "income", "turnover"],
    "profit": ["margin", "earnings", "income"],
    "margin": ["profit", "profitability"],
    "leave": ["absence", "pto"],
    "policy": ["policies", "procedure", "guideline"],
    "error": ["fault", "failure", "code", "troubleshooting"],
    "decline": ["decrease", "decreased", "drop", "reduction", "fell"],
    "decrease": ["decline", "declined", "drop", "reduction", "fell"],
    "currency": ["foreign-exchange", "fx", "exchange"],
}


@dataclass
class ScoredChunk:
    chunk_id: str
    score: float
    reasons: list[str] = field(default_factory=list)


def expand_query(query: str) -> list[str]:
    """Return query tokens plus a bounded set of local synonyms."""
    terms = tokenize(query)
    expanded = list(terms)
    for t in terms:
        for syn in QUERY_EXPANSIONS.get(t, [])[:4]:
            if syn not in expanded:
                expanded.append(syn)
    return expanded


class BM25Index:
    """In-memory BM25 index over chunk text and metadata."""

    def __init__(self) -> None:
        self.doc_freqs: Counter[str] = Counter()
        self.term_freqs: dict[str, Counter[str]] = {}
        self.doc_lengths: dict[str, int] = {}
        self.chunk_meta: dict[str, dict[str, Any]] = {}
        self.avg_len: float = 0.0
        self.n_docs: int = 0

    def add(self, chunk_id: str, text: str, meta: dict[str, Any]) -> None:
        # Weight heading/keyword text by including it alongside the body.
        boosted = text + " " + " ".join([meta.get("heading", "")] * 3)
        boosted += " " + " ".join(meta.get("keywords", []))
        tokens = tokenize(boosted)
        tf = Counter(tokens)
        self.term_freqs[chunk_id] = tf
        self.doc_lengths[chunk_id] = len(tokens)
        for term in tf:
            self.doc_freqs[term] += 1
        self.chunk_meta[chunk_id] = meta
        self.n_docs = len(self.term_freqs)
        self.avg_len = sum(self.doc_lengths.values()) / max(1, self.n_docs)

    def _idf(self, term: str) -> float:
        df = self.doc_freqs.get(term, 0)
        return math.log(1 + (self.n_docs - df + 0.5) / (df + 0.5))

    def score(self, chunk_id: str, terms: list[str]) -> float:
        tf = self.term_freqs.get(chunk_id)
        if not tf:
            return 0.0
        length = self.doc_lengths[chunk_id]
        total = 0.0
        for term in terms:
            f = tf.get(term, 0)
            if f == 0:
                continue
            idf = self._idf(term)
            denom = f + BM25_K1 * (1 - BM25_B + BM25_B * length / max(1.0, self.avg_len))
            total += idf * (f * (BM25_K1 + 1)) / denom
        return total

    def search(
        self,
        query: str,
        chunk_texts: dict[str, str],
        filters: dict[str, Any] | None = None,
        top_k: int = 3,
        candidates: int = 50,
    ) -> list[ScoredChunk]:
        """Staged retrieval: metadata filter -> BM25 -> rerank signals."""
        terms = expand_query(query)
        query_lower = query.lower()
        phrase = query_lower.strip('"') if '"' in query else None

        results: list[ScoredChunk] = []
        for chunk_id, meta in self.chunk_meta.items():
            if filters and not _passes_filters(meta, filters):
                continue
            base = self.score(chunk_id, terms)
            reasons: list[str] = []
            if base > 0:
                reasons.append("lexical")
            bonus = 0.0
            heading = (meta.get("heading") or "").lower()
            if heading and any(t in heading for t in terms):
                bonus += 1.5
                reasons.append("heading-match")
            text = chunk_texts.get(chunk_id, "").lower()
            if phrase and phrase in text:
                bonus += 3.0
                reasons.append("exact-phrase")
            for ent in meta.get("entities", []):
                if ent.lower() in query_lower:
                    bonus += 1.0
                    reasons.append("entity-match")
                    break
            for d in meta.get("dates", []):
                if d.lower() in query_lower:
                    bonus += 0.8
                    reasons.append("date-match")
                    break
            m = re.search(r"\b(?:section|clause|article)\s+(\d+(?:\.\d+)*)", query_lower)
            if m and m.group(1) in text:
                bonus += 2.0
                reasons.append("clause-match")
            if meta.get("chunk_type") == "table" and any(
                w in query_lower for w in ("table", "figure", "how much", "amount", "revenue", "expenses")
            ):
                bonus += 0.5
                reasons.append("table-priority")
            total = base + bonus
            if total > 0:
                results.append(ScoredChunk(chunk_id, total, reasons))

        results.sort(key=lambda r: r.score, reverse=True)
        return results[: max(top_k, min(candidates, len(results)))][:candidates]


def _passes_filters(meta: dict[str, Any], filters: dict[str, Any]) -> bool:
    for key, wanted in filters.items():
        if wanted is None:
            continue
        if key == "document_id" and meta.get("document_id") != wanted:
            return False
        if key == "chunk_type" and meta.get("chunk_type") != wanted:
            return False
        if key == "page":
            if not (meta.get("page_start", 0) <= wanted <= meta.get("page_end", 0)):
                return False
        if key == "section":
            path = " / ".join(meta.get("section_path", [])).lower()
            if str(wanted).lower() not in path:
                return False
    return True


def select_within_budget(
    ranked: list[ScoredChunk],
    chunk_meta: dict[str, dict[str, Any]],
    top_k: int,
    max_tokens: int,
    max_chunks: int = 8,
) -> tuple[list[ScoredChunk], list[ScoredChunk]]:
    """Select the highest-value chunks within a token budget.

    Always keeps at least one complete high-confidence chunk.
    Returns (selected, excluded_high_scoring).
    """
    selected: list[ScoredChunk] = []
    excluded: list[ScoredChunk] = []
    used = 0
    for sc in ranked:
        tokens = chunk_meta.get(sc.chunk_id, {}).get("token_count", 0)
        if len(selected) >= max_chunks or len(selected) >= top_k:
            if sc.score > 0:
                excluded.append(sc)
            continue
        if selected and used + tokens > max_tokens:
            excluded.append(sc)
            continue
        selected.append(sc)
        used += tokens
    return selected, excluded


def deduplicate(
    selected: list[ScoredChunk], chunk_texts: dict[str, str], threshold: float = 0.85
) -> list[ScoredChunk]:
    """Remove chunks whose token sets almost fully overlap a higher-ranked chunk."""
    kept: list[ScoredChunk] = []
    kept_sets: list[set[str]] = []
    for sc in selected:
        tokens = set(tokenize(chunk_texts.get(sc.chunk_id, "")))
        if not tokens:
            kept.append(sc)
            kept_sets.append(tokens)
            continue
        redundant = any(
            len(tokens & prev) / len(tokens) >= threshold for prev in kept_sets if prev
        )
        if not redundant:
            kept.append(sc)
            kept_sets.append(tokens)
    return kept


def needs_neighbor(chunk_text: str, meta: dict[str, Any]) -> bool:
    """Conditional neighbor expansion: only when the chunk looks incomplete."""
    stripped = chunk_text.strip()
    if not stripped:
        return False
    first = stripped.splitlines()[0].strip()
    if first and first[0].islower():  # starts mid-thought
        return True
    if meta.get("chunk_type") == "table" and "title" not in stripped.lower()[:120]:
        return True
    if re.search(r"\bas (?:defined|described|set forth) (?:above|in section)\b", stripped, re.I):
        return True
    if not re.search(r"[.!?]\s*$", stripped):  # ends mid-sentence
        return True
    return False
