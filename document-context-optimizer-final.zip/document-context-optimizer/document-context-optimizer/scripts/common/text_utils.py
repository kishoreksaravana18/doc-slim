"""Text utilities: keyword, date, and entity extraction; heading detection."""
from __future__ import annotations

import re
from collections import Counter

STOPWORDS = {
    "the", "a", "an", "and", "or", "but", "of", "to", "in", "on", "for", "with",
    "by", "at", "as", "is", "are", "was", "were", "be", "been", "being", "that",
    "this", "these", "those", "it", "its", "from", "will", "shall", "may", "can",
    "not", "no", "any", "all", "such", "if", "then", "than", "so", "we", "our",
    "you", "your", "they", "their", "he", "she", "his", "her", "have", "has",
    "had", "do", "does", "did", "which", "who", "whom", "what", "when", "where",
    "how", "into", "upon", "under", "over", "other", "each", "per", "also",
}

DATE_PATTERN = re.compile(
    r"\b(?:"
    r"\d{4}-\d{2}-\d{2}"
    r"|\d{1,2}/\d{1,2}/\d{2,4}"
    r"|(?:January|February|March|April|May|June|July|August|September|October|November|December)"
    r"\s+\d{1,2},?\s+\d{4}"
    r"|(?:19|20)\d{2}"
    r")\b"
)

ENTITY_PATTERN = re.compile(r"\b(?:[A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)+)\b")

CLAUSE_PATTERN = re.compile(r"\b(?:Section|Clause|Article)\s+\d+(?:\.\d+)*\b", re.I)


def tokenize(text: str) -> list[str]:
    """Lowercase word tokens with stopwords removed."""
    words = re.findall(r"[a-zA-Z0-9][a-zA-Z0-9\-\.]*", text.lower())
    return [w for w in words if w not in STOPWORDS and len(w) > 1]


def extract_keywords(text: str, limit: int = 8) -> list[str]:
    counts = Counter(tokenize(text))
    return [w for w, _ in counts.most_common(limit)]


def extract_dates(text: str, limit: int = 12) -> list[str]:
    seen: list[str] = []
    for m in DATE_PATTERN.finditer(text):
        v = m.group(0)
        if v not in seen:
            seen.append(v)
        if len(seen) >= limit:
            break
    return seen

def extract_entities(text: str, limit: int = 10) -> list[str]:
    counts = Counter(m.group(0) for m in ENTITY_PATTERN.finditer(text))
    return [e for e, _ in counts.most_common(limit)]


def extract_clause_refs(text: str) -> list[str]:
    seen: list[str] = []
    for m in CLAUSE_PATTERN.finditer(text):
        v = m.group(0)
        if v not in seen:
            seen.append(v)
    return seen


def is_probable_heading(line: str) -> bool:
    """Heuristic heading detection for plain text."""
    stripped = line.strip()
    if not stripped or len(stripped) > 90:
        return False
    if re.match(r"^#{1,6}\s+", stripped):  # markdown
        return True
    if re.match(r"^(?:\d+(?:\.\d+)*|[IVXLC]+\.)\s+\S", stripped):  # numbered
        return True
    if stripped.isupper() and len(stripped) > 3:
        return True
    words = stripped.split()
    if 1 < len(words) <= 8 and stripped == stripped.title() and not stripped.endswith((".", ",", ";")):
        return True
    return False


def first_sentence(text: str, max_chars: int = 180) -> str:
    """Compact single-sentence summary fallback: the first sentence, truncated."""
    text = " ".join(text.split())
    m = re.search(r"^(.{20,}?[.!?])\s", text)
    sentence = m.group(1) if m else text
    return sentence[:max_chars]
