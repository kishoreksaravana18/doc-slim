"""Token estimation.

Provides a local offline estimator by default. Estimates are labeled as
estimates everywhere; they are not exact API billing counts.
"""
from __future__ import annotations

import re

# Rough heuristic: English prose averages ~4 characters per token.
# Word-based estimate is blended in for robustness on dense text.
CHARS_PER_TOKEN = 4.0
TOKENS_PER_WORD = 1.33

ESTIMATOR_NAME = "local-heuristic-v1 (blend of chars/4 and words*1.33)"


def estimate_tokens(text: str) -> int:
    """Estimate token count for text using a local offline heuristic."""
    if not text:
        return 0
    char_estimate = len(text) / CHARS_PER_TOKEN
    words = len(re.findall(r"\S+", text))
    word_estimate = words * TOKENS_PER_WORD
    return max(1, round((char_estimate + word_estimate) / 2))


def context_reduction_percentage(baseline_tokens: int, optimized_tokens: int) -> float:
    """(1 - optimized / baseline) * 100. Returns 0.0 for a zero baseline."""
    if baseline_tokens <= 0:
        return 0.0
    return (1 - optimized_tokens / baseline_tokens) * 100
