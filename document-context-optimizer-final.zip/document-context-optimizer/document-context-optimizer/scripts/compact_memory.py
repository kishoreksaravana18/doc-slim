#!/usr/bin/env python3
"""Compact session memory: small structured JSON files that carry
confirmed facts, chunk IDs, and citations across follow-up questions.

Never stores full document text or full retrieved chunks.
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common.token_utils import estimate_tokens  # noqa: E402

DEFAULT_MAX_MEMORY_TOKENS = 800
MAX_FACT_CHARS = 300  # guard against full chunks being stuffed into memory


def load_memory(path: Path) -> dict[str, Any]:
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return {
        "session_id": datetime.now(timezone.utc).strftime("%Y-%m-%d-") + "session",
        "documents": [],
        "answered_questions": [],
        "open_questions": [],
        "known_contradictions": [],
        "estimated_tokens": 0,
    }


def add_answer(
    memory: dict[str, Any],
    question: str,
    retrieved_chunks: list[str],
    confirmed_facts: list[str],
    citations: list[str],
    document: dict[str, str] | None = None,
) -> dict[str, Any]:
    facts = []
    for f in confirmed_facts:
        if len(f) > MAX_FACT_CHARS:
            raise ValueError(
                f"Fact exceeds {MAX_FACT_CHARS} characters; store a short fact, not chunk text."
            )
        facts.append(f)
    if document and document.get("document_id") not in {d.get("document_id") for d in memory["documents"]}:
        memory["documents"].append(document)
    memory["answered_questions"].append({
        "question": question,
        "retrieved_chunks": retrieved_chunks,
        "confirmed_facts": facts,
        "citations": citations,
    })
    memory["estimated_tokens"] = estimate_tokens(json.dumps(memory))
    return memory


def compact(memory: dict[str, Any], max_tokens: int = DEFAULT_MAX_MEMORY_TOKENS) -> dict[str, Any]:
    """Shrink memory to the token budget: dedupe facts, drop stale retrieval
    detail, keep citations and unresolved contradictions."""
    memory["estimated_tokens"] = estimate_tokens(json.dumps(memory))
    if memory["estimated_tokens"] <= max_tokens:
        return memory
    # 1. Merge duplicate facts across answers.
    seen_facts: set[str] = set()
    for qa in memory["answered_questions"]:
        unique = []
        for f in qa["confirmed_facts"]:
            if f not in seen_facts:
                unique.append(f)
                seen_facts.add(f)
        qa["confirmed_facts"] = unique
    # 2. Drop chunk ID lists from oldest answers first (citations kept).
    for qa in memory["answered_questions"][:-2]:
        qa["retrieved_chunks"] = []
        memory["estimated_tokens"] = estimate_tokens(json.dumps(memory))
        if memory["estimated_tokens"] <= max_tokens:
            return memory
    # 3. Drop oldest answered questions entirely, keeping the two most recent.
    while len(memory["answered_questions"]) > 2 and memory["estimated_tokens"] > max_tokens:
        memory["answered_questions"].pop(0)
        memory["estimated_tokens"] = estimate_tokens(json.dumps(memory))
    return memory


def main() -> int:
    parser = argparse.ArgumentParser(description="Manage compact session memory.")
    parser.add_argument("memory_file", type=Path)
    parser.add_argument("--add-question")
    parser.add_argument("--chunks", nargs="*", default=[])
    parser.add_argument("--facts", nargs="*", default=[])
    parser.add_argument("--citations", nargs="*", default=[])
    parser.add_argument("--document-id")
    parser.add_argument("--document-name")
    parser.add_argument("--index-path")
    parser.add_argument("--max-tokens", type=int, default=DEFAULT_MAX_MEMORY_TOKENS)
    parser.add_argument("--show", action="store_true")
    args = parser.parse_args()

    memory = load_memory(args.memory_file)
    if args.add_question:
        document = None
        if args.document_id:
            document = {
                "document_id": args.document_id,
                "name": args.document_name or "",
                "index_path": args.index_path or "",
            }
        try:
            memory = add_answer(memory, args.add_question, args.chunks, args.facts, args.citations, document)
        except ValueError as exc:
            print(f"Memory update rejected: {exc}", file=sys.stderr)
            return 1
        memory = compact(memory, max_tokens=args.max_tokens)
        args.memory_file.parent.mkdir(parents=True, exist_ok=True)
        args.memory_file.write_text(json.dumps(memory, indent=2), encoding="utf-8")
        print(f"Memory updated ({memory['estimated_tokens']} estimated tokens).")
    if args.show or not args.add_question:
        print(json.dumps(memory, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
