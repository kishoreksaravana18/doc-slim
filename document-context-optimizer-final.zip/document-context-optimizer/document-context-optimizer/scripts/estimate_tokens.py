#!/usr/bin/env python3
"""Estimate token counts for files or stdin. Local estimates only;
these are not exact API billing values."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common.token_utils import ESTIMATOR_NAME, context_reduction_percentage, estimate_tokens  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description="Estimate token counts (local heuristic).")
    parser.add_argument("files", nargs="*", type=Path)
    parser.add_argument("--baseline", type=int, help="Baseline tokens for reduction calculation")
    parser.add_argument("--optimized", type=int, help="Optimized tokens for reduction calculation")
    args = parser.parse_args()

    out: dict = {"estimator": ESTIMATOR_NAME, "note": "Estimates, not exact API counts."}
    if args.baseline is not None and args.optimized is not None:
        out["context_reduction_percentage"] = round(
            context_reduction_percentage(args.baseline, args.optimized), 2
        )
    results = []
    for f in args.files:
        if not f.exists():
            print(f"File not found: {f}", file=sys.stderr)
            return 1
        text = f.read_text(encoding="utf-8", errors="replace")
        results.append({"file": str(f), "estimated_tokens": estimate_tokens(text)})
    if not args.files and not sys.stdin.isatty():
        results.append({"file": "<stdin>", "estimated_tokens": estimate_tokens(sys.stdin.read())})
    out["results"] = results
    print(json.dumps(out, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
