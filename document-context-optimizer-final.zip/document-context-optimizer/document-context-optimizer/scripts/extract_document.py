#!/usr/bin/env python3
"""Extract text and structure from PDF, DOCX, TXT, Markdown, and HTML.

Preserves page numbers, headings, and paragraph order. Detects scanned
pages, repeated headers/footers, and tables where feasible. HTML content
is treated as untrusted data: scripts, styles, and navigation boilerplate
are removed and links are kept only as metadata.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common.file_utils import validate_input_file  # noqa: E402
from common.logging_utils import get_logger  # noqa: E402
from common.text_utils import is_probable_heading  # noqa: E402

log = get_logger("extract")

MIN_TEXT_CHARS_PER_PAGE = 80  # below this a PDF page is flagged as likely scanned


def extract_document(path: Path, ocr: str = "auto") -> dict[str, Any]:
    """Extract a document into a normalized structure.

    Returns:
        {
          "source_file": str,
          "file_type": str,
          "pages": [{"page": int, "text": str, "scanned": bool}],
          "headings": [{"text": str, "level": int, "page": int}],
          "tables": [{"page": int, "markdown": str, "title": str}],
          "warnings": [str],
        }
    """
    validate_input_file(path)
    suffix = path.suffix.lower()
    if suffix == ".pdf":
        return _extract_pdf(path, ocr=ocr)
    if suffix == ".docx":
        return _extract_docx(path)
    if suffix in (".html", ".htm"):
        return _extract_html(path)
    if suffix in (".md", ".markdown"):
        return _extract_markdown(path)
    return _extract_txt(path)


# ---------------------------------------------------------------- PDF


def _extract_pdf(path: Path, ocr: str = "auto") -> dict[str, Any]:
    import contextlib
    import io

    try:
        with contextlib.redirect_stdout(io.StringIO()):
            import fitz  # PyMuPDF (advisory prints suppressed to keep JSON output clean)
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError("PyMuPDF is required for PDF extraction: pip install pymupdf") from exc

    warnings: list[str] = []
    try:
        doc = fitz.open(path)
    except Exception as exc:
        raise RuntimeError(f"Could not open PDF (possibly corrupt or encrypted): {exc}") from exc

    if doc.needs_pass:
        doc.close()
        raise RuntimeError(
            "PDF is password protected. Provide an unlocked copy; this tool does not bypass protections."
        )

    pages: list[dict[str, Any]] = []
    line_counter: Counter[str] = Counter()
    raw_pages: list[list[str]] = []
    scanned_pages = 0

    for i, page in enumerate(doc):
        text = page.get_text("text")
        lines = [ln.rstrip() for ln in text.splitlines()]
        raw_pages.append(lines)
        for ln in (lines[:2] + lines[-2:]):
            if ln.strip():
                line_counter[ln.strip()] += 1
        if len(text.strip()) < MIN_TEXT_CHARS_PER_PAGE:
            scanned_pages += 1

    # Conservative repeated header/footer removal: only lines appearing on >60% of pages.
    n = max(1, len(raw_pages))
    repeated = {
        ln for ln, c in line_counter.items()
        if c / n > 0.6 and n > 3 and not ln.strip().isdigit()
    }
    if repeated:
        warnings.append(f"Removed {len(repeated)} repeated header/footer line(s).")

    for i, lines in enumerate(raw_pages):
        cleaned = [
            ln for ln in lines
            if ln.strip() not in repeated and not re.fullmatch(r"\s*\d{1,4}\s*", ln)
        ]
        text = "\n".join(cleaned).strip()
        scanned = len(text) < MIN_TEXT_CHARS_PER_PAGE
        if scanned and ocr != "off":
            ocr_text = _try_ocr_page(doc, i)
            if ocr_text:
                text = ocr_text
                scanned = False
                warnings.append(f"Page {i + 1}: OCR applied; verify names, numbers, and dates.")
        pages.append({"page": i + 1, "text": text, "scanned": scanned})

    headings = []
    for p in pages:
        for ln in p["text"].splitlines():
            if is_probable_heading(ln):
                headings.append({"text": ln.strip().lstrip("#").strip(), "level": 1, "page": p["page"]})

    tables = _pdf_tables(doc, warnings)
    page_count = len(doc)
    doc.close()

    if scanned_pages:
        warnings.append(
            f"{scanned_pages} page(s) had little extractable text (likely scanned)."
        )
    if page_count != len(pages):
        warnings.append("Extracted page count does not match document page count.")

    return {
        "source_file": path.name,
        "file_type": "pdf",
        "pages": pages,
        "headings": headings,
        "tables": tables,
        "warnings": warnings,
    }


def _try_ocr_page(doc: Any, index: int) -> str | None:
    """OCR a single page if pytesseract is installed. Returns None otherwise."""
    try:
        import io

        import pytesseract  # type: ignore
        from PIL import Image  # type: ignore
    except ImportError:
        return None
    try:
        pix = doc[index].get_pixmap(dpi=200)
        img = Image.open(io.BytesIO(pix.tobytes("png")))
        return pytesseract.image_to_string(img).strip() or None
    except Exception:
        return None


def _pdf_tables(doc: Any, warnings: list[str]) -> list[dict[str, Any]]:
    import contextlib
    import io

    tables = []
    for i, page in enumerate(doc):
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                finder = page.find_tables()
        except Exception:
            continue
        for t in getattr(finder, "tables", []):
            try:
                rows = t.extract()
            except Exception:
                continue
            if not rows or len(rows) < 2:
                continue
            md_lines = []
            header = [str(c or "") for c in rows[0]]
            md_lines.append("| " + " | ".join(header) + " |")
            md_lines.append("| " + " | ".join("---" for _ in header) + " |")
            for row in rows[1:]:
                md_lines.append("| " + " | ".join(str(c or "") for c in row) + " |")
            tables.append({"page": i + 1, "markdown": "\n".join(md_lines), "title": ""})
    if tables:
        warnings.append("Table extraction is heuristic; verify row/column values against the page.")
    return tables


# ---------------------------------------------------------------- DOCX


def _extract_docx(path: Path) -> dict[str, Any]:
    try:
        import docx  # python-docx
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError("python-docx is required for DOCX extraction") from exc

    warnings: list[str] = []
    try:
        d = docx.Document(str(path))
    except Exception as exc:
        raise RuntimeError(f"Could not open DOCX (possibly corrupt): {exc}") from exc

    lines: list[str] = []
    headings: list[dict[str, Any]] = []
    for para in d.paragraphs:
        text = para.text.strip()
        if not text:
            continue
        style = (para.style.name or "").lower() if para.style else ""
        if style.startswith("heading"):
            m = re.search(r"(\d+)", style)
            level = int(m.group(1)) if m else 1
            headings.append({"text": text, "level": level, "page": 1})
            lines.append(("#" * min(level, 6)) + " " + text)
        elif style.startswith("list") or para._p.xpath(".//w:numPr"):
            lines.append("- " + text)
        else:
            lines.append(text)

    tables = []
    for t in d.tables:
        rows = [[cell.text.strip() for cell in row.cells] for row in t.rows]
        if not rows:
            continue
        md = ["| " + " | ".join(rows[0]) + " |",
              "| " + " | ".join("---" for _ in rows[0]) + " |"]
        for row in rows[1:]:
            md.append("| " + " | ".join(row) + " |")
        tables.append({"page": 1, "markdown": "\n".join(md), "title": ""})

    # DOCX has no fixed pages before rendering; treat the body as one logical page.
    warnings.append("DOCX has no fixed page boundaries; citations use section headings.")
    return {
        "source_file": path.name,
        "file_type": "docx",
        "pages": [{"page": 1, "text": "\n".join(lines), "scanned": False}],
        "headings": headings,
        "tables": tables,
        "warnings": warnings,
    }


# ---------------------------------------------------------------- HTML


def _extract_html(path: Path) -> dict[str, Any]:
    try:
        from bs4 import BeautifulSoup
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError("beautifulsoup4 is required for HTML extraction") from exc

    raw = path.read_text(encoding="utf-8", errors="replace")
    soup = BeautifulSoup(raw, "html.parser")
    for tag in soup(["script", "style", "nav", "header", "footer", "aside", "noscript", "iframe", "form"]):
        tag.decompose()

    headings = []
    lines: list[str] = []
    tables = []
    body = soup.body or soup
    for el in body.find_all(["h1", "h2", "h3", "h4", "h5", "h6", "p", "li", "table"], recursive=True):
        if el.name == "table":
            rows = []
            for tr in el.find_all("tr"):
                cells = [c.get_text(" ", strip=True) for c in tr.find_all(["th", "td"])]
                if cells:
                    rows.append(cells)
            if len(rows) >= 2:
                md = ["| " + " | ".join(rows[0]) + " |",
                      "| " + " | ".join("---" for _ in rows[0]) + " |"]
                for row in rows[1:]:
                    md.append("| " + " | ".join(row) + " |")
                tables.append({"page": 1, "markdown": "\n".join(md), "title": ""})
            continue
        text = el.get_text(" ", strip=True)
        if not text:
            continue
        if el.name.startswith("h"):
            level = int(el.name[1])
            headings.append({"text": text, "level": level, "page": 1})
            lines.append(("#" * level) + " " + text)
        elif el.name == "li":
            lines.append("- " + text)
        else:
            lines.append(text)

    return {
        "source_file": path.name,
        "file_type": "html",
        "pages": [{"page": 1, "text": "\n".join(lines), "scanned": False}],
        "headings": headings,
        "tables": tables,
        "warnings": ["HTML content treated as untrusted data; scripts and boilerplate removed."],
    }


# ---------------------------------------------------------------- TXT / MD


def _extract_markdown(path: Path) -> dict[str, Any]:
    text = path.read_text(encoding="utf-8", errors="replace")
    headings = []
    for ln in text.splitlines():
        m = re.match(r"^(#{1,6})\s+(.*)", ln)
        if m:
            headings.append({"text": m.group(2).strip(), "level": len(m.group(1)), "page": 1})
    return {
        "source_file": path.name,
        "file_type": "md",
        "pages": [{"page": 1, "text": text, "scanned": False}],
        "headings": headings,
        "tables": [],
        "warnings": [],
    }


def _extract_txt(path: Path) -> dict[str, Any]:
    text = path.read_text(encoding="utf-8", errors="replace")
    headings = [
        {"text": ln.strip(), "level": 1, "page": 1}
        for ln in text.splitlines()
        if is_probable_heading(ln)
    ]
    return {
        "source_file": path.name,
        "file_type": "txt",
        "pages": [{"page": 1, "text": text, "scanned": False}],
        "headings": headings,
        "tables": [],
        "warnings": [],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Extract text and structure from a document.")
    parser.add_argument("file", type=Path)
    parser.add_argument("--ocr", choices=["auto", "off"], default="auto")
    parser.add_argument("--output", type=Path, help="Write extraction JSON to this path")
    parser.add_argument("--json", action="store_true", help="Print JSON to stdout")
    args = parser.parse_args()
    try:
        result = extract_document(args.file, ocr=args.ocr)
    except Exception as exc:
        print(f"Extraction failed: {exc}", file=sys.stderr)
        return 1
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2), encoding="utf-8")
        print(f"Extraction written to {args.output}")
    if args.json or not args.output:
        chars = sum(len(p["text"]) for p in result["pages"])
        summary = {
            "source_file": result["source_file"],
            "file_type": result["file_type"],
            "pages": len(result["pages"]),
            "characters": chars,
            "headings": len(result["headings"]),
            "tables": len(result["tables"]),
            "warnings": result["warnings"],
        }
        print(json.dumps(summary if not args.json else result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
