#!/usr/bin/env python3
"""Inspect a document before full processing.

Reports size, page count, estimated tokens, searchability, structure
signals, and whether an existing index matches the file hash.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common.file_utils import document_id_from_hash, sha256_file, validate_input_file  # noqa: E402
from common.models import SCHEMA_VERSION, InspectionResult  # noqa: E402
from common.token_utils import estimate_tokens  # noqa: E402
from extract_document import extract_document  # noqa: E402

DEFAULT_WORKSPACE = Path("workspace")


def find_existing_index(file_hash: str, workspace: Path) -> Path | None:
    doc_id = document_id_from_hash(file_hash)
    index_path = workspace / "indexes" / doc_id / "index.json"
    if not index_path.exists():
        return None
    try:
        data = json.loads(index_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None
    meta = data.get("metadata", {})
    if meta.get("document_hash") != file_hash:
        return None
    if meta.get("schema_version") != SCHEMA_VERSION:
        return None
    return index_path


def inspect_document(path: Path, workspace: Path = DEFAULT_WORKSPACE) -> InspectionResult:
    validate_input_file(path)
    file_hash = sha256_file(path)
    doc_id = document_id_from_hash(file_hash)
    extraction = extract_document(path, ocr="off")

    char_count = sum(len(p["text"]) for p in extraction["pages"])
    scanned_pages = sum(1 for p in extraction["pages"] if p.get("scanned"))
    searchable = char_count > 0 and scanned_pages < len(extraction["pages"])

    return InspectionResult(
        document_id=doc_id,
        file_name=path.name,
        file_type=extraction["file_type"],
        file_size_bytes=path.stat().st_size,
        page_count=len(extraction["pages"]),
        character_count=char_count,
        estimated_tokens=estimate_tokens("\n".join(p["text"] for p in extraction["pages"])),
        searchable=searchable,
        ocr_required=scanned_pages > 0,
        language="en",  # heuristic default; language detection is out of scope for v0.1
        headings_detected=len(extraction["headings"]) > 0,
        tables_detected=len(extraction["tables"]),
        existing_index_found=find_existing_index(file_hash, workspace) is not None,
        warnings=extraction["warnings"],
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="Inspect a document before processing.")
    parser.add_argument("file", type=Path)
    parser.add_argument("--workspace", type=Path, default=DEFAULT_WORKSPACE)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    try:
        result = inspect_document(args.file, workspace=args.workspace)
    except Exception as exc:
        print(f"Inspection failed: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result.to_dict(), indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
