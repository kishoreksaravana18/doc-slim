#!/usr/bin/env python3
"""Retrieve the smallest sufficient set of chunks for a query.

Staged: metadata filtering -> BM25 lexical ranking -> rerank signals ->
token-budget selection -> deduplication -> conditional neighbor expansion.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common.retrieval import (  # noqa: E402
    BM25Index,
    deduplicate,
    needs_neighbor,
    select_within_budget,
)
from common.token_utils import estimate_tokens  # noqa: E402

DEFAULT_TOP_K = 3
DEFAULT_MAX_TOKENS = 6000
DEFAULT_MAX_CHUNKS = 8


def load_index(index_path: Path) -> tuple[dict[str, Any], dict[str, dict[str, Any]], dict[str, str]]:
    """Load index metadata, chunk metadata, and chunk texts."""
    data = json.loads(index_path.read_text(encoding="utf-8"))
    chunk_meta = {c["chunk_id"]: c for c in data["chunks"]}
    chunk_texts: dict[str, str] = {}
    for cid, meta in chunk_meta.items():
        p = Path(meta["content_path"])
        if not p.is_absolute():
            p = index_path.parent.parent.parent.parent / p if not p.exists() else p
        try:
            chunk_texts[cid] = p.read_text(encoding="utf-8")
        except OSError:
            chunk_texts[cid] = ""
    return data, chunk_meta, chunk_texts


def retrieve(
    index_path: Path,
    query: str,
    top_k: int = DEFAULT_TOP_K,
    max_tokens: int = DEFAULT_MAX_TOKENS,
    max_chunks: int = DEFAULT_MAX_CHUNKS,
    include_neighbors: str = "auto",
    filters: dict[str, Any] | None = None,
) -> dict[str, Any]:
    start = time.time()
    data, chunk_meta, chunk_texts = load_index(index_path)

    bm25 = BM25Index()
    for cid, meta in chunk_meta.items():
        bm25.add(cid, chunk_texts.get(cid, ""), meta)

    ranked = bm25.search(query, chunk_texts, filters=filters, top_k=top_k)
    selected, excluded = select_within_budget(ranked, chunk_meta, top_k, max_tokens, max_chunks)
    selected = deduplicate(selected, chunk_texts)

    # Conditional neighbor expansion.
    neighbor_notes: list[str] = []
    if include_neighbors == "auto":
        from common.retrieval import ScoredChunk

        selected_ids = {s.chunk_id for s in selected}
        additions: list[ScoredChunk] = []
        for sc in list(selected):
            meta = chunk_meta[sc.chunk_id]
            text = chunk_texts.get(sc.chunk_id, "")
            if needs_neighbor(text, meta):
                for nid in (meta.get("previous_chunk_id"), meta.get("next_chunk_id")):
                    if nid and nid not in selected_ids and len(selected) + len(additions) < max_chunks:
                        n_tokens = chunk_meta.get(nid, {}).get("token_count", 0)
                        used = sum(chunk_meta[s.chunk_id]["token_count"] for s in selected + additions)
                        if used + n_tokens <= max_tokens * 2:  # expanded budget
                            additions.append(ScoredChunk(nid, 0.0, ["neighbor-expansion"]))
                            selected_ids.add(nid)
                            neighbor_notes.append(
                                f"Included neighbor {nid} because {sc.chunk_id} looked incomplete."
                            )
        selected.extend(additions)

    results = []
    used_tokens = 0
    for sc in selected:
        meta = chunk_meta[sc.chunk_id]
        used_tokens += meta["token_count"]
        results.append({
            "chunk_id": sc.chunk_id,
            "score": round(sc.score, 3),
            "reasons": sc.reasons,
            "page_start": meta["page_start"],
            "page_end": meta["page_end"],
            "heading": meta["heading"],
            "section_path": meta["section_path"],
            "chunk_type": meta["chunk_type"],
            "token_count": meta["token_count"],
            "text": chunk_texts.get(sc.chunk_id, ""),
        })

    return {
        "query": query,
        "document_id": data["metadata"]["document_id"],
        "source_file": data["metadata"]["source_file"],
        "retrieved": results,
        "excluded_high_scoring": [
            {"chunk_id": e.chunk_id, "score": round(e.score, 3)} for e in excluded[:5]
        ],
        "neighbor_notes": neighbor_notes,
        "estimated_context_tokens": used_tokens + estimate_tokens(query),
        "retrieval_latency_seconds": round(time.time() - start, 3),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Retrieve relevant chunks for a query.")
    parser.add_argument("--index", type=Path, required=True)
    parser.add_argument("--query", required=True)
    parser.add_argument("--top-k", type=int, default=DEFAULT_TOP_K)
    parser.add_argument("--max-tokens", type=int, default=DEFAULT_MAX_TOKENS)
    parser.add_argument("--max-chunks", type=int, default=DEFAULT_MAX_CHUNKS)
    parser.add_argument("--include-neighbors", choices=["auto", "off"], default="auto")
    parser.add_argument("--filter-section", default=None)
    parser.add_argument("--filter-type", default=None, choices=[None, "prose", "table"])
    parser.add_argument("--output", choices=["json", "text"], default="json")
    args = parser.parse_args()
    if not args.index.exists():
        print(f"Index not found: {args.index}. Run build_index.py first.", file=sys.stderr)
        return 1
    filters = {}
    if args.filter_section:
        filters["section"] = args.filter_section
    if args.filter_type:
        filters["chunk_type"] = args.filter_type
    try:
        result = retrieve(
            args.index, args.query,
            top_k=args.top_k, max_tokens=args.max_tokens, max_chunks=args.max_chunks,
            include_neighbors=args.include_neighbors, filters=filters or None,
        )
    except Exception as exc:
        print(f"Retrieval failed: {exc}", file=sys.stderr)
        return 1
    if args.output == "json":
        print(json.dumps(result, indent=2))
    else:
        for r in result["retrieved"]:
            pages = f"p{r['page_start']}" if r["page_start"] == r["page_end"] else f"pp{r['page_start']}-{r['page_end']}"
            print(f"[{r['chunk_id']}] score={r['score']} {pages} {r['heading']}")
    if not result["retrieved"]:
        print("No chunks matched the query. Try broader terms or check the document map.", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
