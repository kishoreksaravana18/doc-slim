#!/usr/bin/env python3
"""Validate an index: schema, hashes, chunk files, links, and safe paths."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common.models import SCHEMA_VERSION  # noqa: E402

REQUIRED_META = {
    "schema_version", "document_id", "document_hash", "source_file",
    "created_at", "chunking_settings", "tokenizer", "page_count",
    "estimated_source_tokens", "chunk_count",
}
REQUIRED_CHUNK = {
    "chunk_id", "document_id", "source_file", "page_start", "page_end",
    "section_path", "heading", "chunk_type", "token_count", "content_path",
}


def validate_index(index_path: Path, workspace: Path | None = None) -> tuple[bool, list[str], dict]:
    errors: list[str] = []
    stats = {"chunks": 0, "tables": 0, "missing_files": 0, "invalid_references": 0}
    try:
        data = json.loads(index_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        return False, [f"Index unreadable or invalid JSON: {exc}"], stats

    meta = data.get("metadata", {})
    missing = REQUIRED_META - set(meta)
    if missing:
        errors.append(f"Missing metadata fields: {sorted(missing)}")
    if meta.get("schema_version") != SCHEMA_VERSION:
        errors.append(f"Schema version mismatch: {meta.get('schema_version')} != {SCHEMA_VERSION}")

    chunks = data.get("chunks", [])
    stats["chunks"] = len(chunks)
    if meta.get("chunk_count") not in (None, len(chunks)):
        errors.append("chunk_count does not match actual chunks")

    seen_ids: set[str] = set()
    ids = set()
    for c in chunks:
        missing_c = REQUIRED_CHUNK - set(c)
        if missing_c:
            errors.append(f"Chunk {c.get('chunk_id')} missing fields: {sorted(missing_c)}")
            continue
        cid = c["chunk_id"]
        if cid in seen_ids:
            errors.append(f"Duplicate chunk ID: {cid}")
        seen_ids.add(cid)
        ids.add(cid)
        if c["page_start"] > c["page_end"] or c["page_start"] < 1:
            errors.append(f"{cid}: invalid page range {c['page_start']}-{c['page_end']}")
        if c["token_count"] <= 0:
            errors.append(f"{cid}: non-positive token count")
        if c["chunk_type"] == "table":
            stats["tables"] += 1
        content = Path(c["content_path"])
        if not content.exists():
            errors.append(f"{cid}: missing chunk file {content}")
            stats["missing_files"] += 1
        if workspace:
            try:
                content.resolve().relative_to(workspace.resolve())
            except ValueError:
                errors.append(f"{cid}: content path outside workspace: {content}")

    for c in chunks:
        for key in ("previous_chunk_id", "next_chunk_id"):
            ref = c.get(key)
            if ref and ref not in ids:
                errors.append(f"{c['chunk_id']}: {key} points to unknown chunk {ref}")
                stats["invalid_references"] += 1

    map_path = data.get("document_map_path")
    if not map_path or not Path(map_path).exists():
        errors.append("Document map missing")

    return not errors, errors, stats


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate a document index.")
    parser.add_argument("index", type=Path)
    parser.add_argument("--workspace", type=Path, default=None)
    args = parser.parse_args()
    ok, errors, stats = validate_index(args.index, workspace=args.workspace)
    if ok:
        data = json.loads(args.index.read_text(encoding="utf-8"))
        meta = data["metadata"]
        print("Validation passed")
        print(f"Document: {meta['source_file']}")
        print(f"Chunks: {stats['chunks']}")
        print(f"Tables: {stats['tables']}")
        print(f"Estimated source tokens: {meta['estimated_source_tokens']:,}")
        print(f"Missing files: {stats['missing_files']}")
        print(f"Invalid references: {stats['invalid_references']}")
        return 0
    print("Validation failed", file=sys.stderr)
    for e in errors:
        print(f"- {e}", file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
