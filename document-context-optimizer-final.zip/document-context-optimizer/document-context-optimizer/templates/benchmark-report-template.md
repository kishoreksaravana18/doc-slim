# Benchmark report

- Tokenizer / estimator:
- Note: all token figures are local estimates, not exact API billing counts.

| Case | Doc tokens (est.) | Questions | Baseline A | Baseline B | Optimized | Reduction vs A | Reduction vs B |
|---|---|---|---|---|---|---|---|

## Retrieval quality
| Case | Precision | Recall | Avg chunks | Avg retrieved tokens |
|---|---|---|---|---|

## Limitations
-
