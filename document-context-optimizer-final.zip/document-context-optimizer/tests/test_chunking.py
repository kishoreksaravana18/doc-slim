"""Chunking tests: structure preservation, sizes, IDs, neighbor links."""
from chunk_document import chunk_document
from extract_document import extract_document


def _chunks(sample, tmp_path, **kw):
    extraction = extract_document(sample)
    return chunk_document(extraction, "abc123", tmp_path / "chunks", **kw)


def test_stable_ids_and_neighbor_links(sample_txt, tmp_path):
    chunks = _chunks(sample_txt, tmp_path, target_tokens=150, max_tokens=250, min_tokens=40)
    assert chunks[0].chunk_id == "DOC-abc123-C0000"
    assert chunks[0].previous_chunk_id is None
    if len(chunks) > 1:
        assert chunks[0].next_chunk_id == chunks[1].chunk_id
        assert chunks[1].previous_chunk_id == chunks[0].chunk_id
    assert chunks[-1].next_chunk_id is None


def test_max_size_respected(sample_md, tmp_path):
    chunks = _chunks(sample_md, tmp_path, target_tokens=200, max_tokens=400, min_tokens=50)
    for c in chunks:
        assert c.token_count <= 400 * 1.35  # estimator tolerance


def test_heading_stays_with_first_paragraph(sample_md, tmp_path):
    chunks = _chunks(sample_md, tmp_path, target_tokens=200, max_tokens=400, min_tokens=50)
    joined = {c.chunk_id: (tmp_path / "chunks" / f"{c.chunk_id.split('-')[-1]}.txt").read_text() for c in chunks}
    for cid, text in joined.items():
        if "Executive Summary" in text:
            assert "Revenue grew" in text or "Executive Summary" not in text.splitlines()[-1]
            break
    else:
        raise AssertionError("Executive Summary heading not found in any chunk")


def test_contract_clause_numbers_preserved(sample_txt, tmp_path):
    chunks = _chunks(sample_txt, tmp_path, target_tokens=150, max_tokens=300, min_tokens=40)
    all_text = " ".join(
        (tmp_path / "chunks" / f"C{i:04d}.txt").read_text() for i in range(len(chunks))
    )
    assert "5.1 Termination for Convenience" in all_text


def test_chunk_files_written_separately(sample_txt, tmp_path):
    chunks = _chunks(sample_txt, tmp_path, target_tokens=150, max_tokens=300, min_tokens=40)
    for c in chunks:
        from pathlib import Path
        assert Path(c.content_path).exists()
        assert c.token_count > 0
        assert c.page_start <= c.page_end
