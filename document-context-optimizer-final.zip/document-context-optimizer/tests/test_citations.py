"""Citation-supporting metadata: correct pages, sections, document map."""
import json
from pathlib import Path

from build_index import build_index
from retrieve_chunks import retrieve


def test_retrieved_chunks_carry_page_ranges(sample_pdf, workspace):
    index, _ = build_index(sample_pdf, workspace, target_tokens=150, max_tokens=300, min_tokens=40)
    result = retrieve(index, "termination for convenience notice", top_k=3)
    assert result["retrieved"]
    for r in result["retrieved"]:
        assert r["page_start"] >= 1
        assert r["page_end"] >= r["page_start"]


def test_document_map_has_page_references(sample_pdf, workspace):
    index, _ = build_index(sample_pdf, workspace, target_tokens=150, max_tokens=300, min_tokens=40)
    data = json.loads(index.read_text())
    doc_map = Path(data["document_map_path"]).read_text()
    assert "Page" in doc_map
    assert "# Document map" in doc_map


def test_multi_document_source_identity(sample_txt, sample_md, workspace):
    i1, _ = build_index(sample_txt, workspace)
    i2, _ = build_index(sample_md, workspace)
    d1 = json.loads(i1.read_text())["metadata"]
    d2 = json.loads(i2.read_text())["metadata"]
    assert d1["document_id"] != d2["document_id"]
    assert d1["source_file"] != d2["source_file"]
