"""CLI tests: help, exit codes, JSON output, end-to-end acceptance flow."""
import json
import subprocess
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
SCRIPTS = REPO / "document-context-optimizer" / "scripts"


def run(args, cwd=None):
    return subprocess.run([sys.executable, *args], capture_output=True, text=True, cwd=cwd or REPO)


def test_help_commands():
    for script in ("inspect_document.py", "build_index.py", "retrieve_chunks.py",
                   "answer_context.py", "validate_index.py", "cli.py"):
        r = run([str(SCRIPTS / script), "--help"])
        assert r.returncode == 0, script
        assert "usage" in r.stdout.lower()


def test_missing_file_nonzero_exit():
    r = run([str(SCRIPTS / "inspect_document.py"), "nope.pdf"])
    assert r.returncode == 1
    assert "failed" in r.stderr.lower() or "not found" in r.stderr.lower()


def test_end_to_end_acceptance(sample_pdf, tmp_path):
    ws = tmp_path / "workspace"
    # inspect
    r = run([str(SCRIPTS / "inspect_document.py"), str(sample_pdf), "--workspace", str(ws)])
    assert r.returncode == 0
    info = json.loads(r.stdout)
    assert info["estimated_tokens"] > 0 and info["searchable"]
    # index
    r = run([str(SCRIPTS / "build_index.py"), str(sample_pdf), "--output", str(ws)])
    assert r.returncode == 0
    out = json.loads(r.stdout)
    index_path = out["index_path"]
    assert not out["reused_existing_index"]
    # question 1: retrieval stays within budget, returns termination content
    r = run([str(SCRIPTS / "retrieve_chunks.py"), "--index", index_path,
             "--query", "Can the customer terminate for convenience?", "--max-tokens", "6000"])
    assert r.returncode == 0
    result = json.loads(r.stdout)
    assert result["estimated_context_tokens"] <= 6500
    assert any("Termination" in c["text"] for c in result["retrieved"])
    # memory: facts stored without full chunks
    mem = ws / "memory" / "session.json"
    r = run([str(SCRIPTS / "compact_memory.py"), str(mem), "--add-question",
             "termination for convenience", "--chunks", result["retrieved"][0]["chunk_id"],
             "--facts", "Only the customer may terminate for convenience with thirty days notice.",
             "--citations", "Section 5.1"])
    assert r.returncode == 0
    # follow-up: index reused, no re-extraction
    r = run([str(SCRIPTS / "build_index.py"), str(sample_pdf), "--output", str(ws)])
    assert json.loads(r.stdout)["reused_existing_index"] is True
    # validate
    r = run([str(SCRIPTS / "validate_index.py"), index_path])
    assert r.returncode == 0
    assert "Validation passed" in r.stdout


def test_memory_rejects_full_chunk_text(tmp_path):
    mem = tmp_path / "session.json"
    huge_fact = "x" * 1000
    r = run([str(SCRIPTS / "compact_memory.py"), str(mem), "--add-question", "q",
             "--facts", huge_fact])
    assert r.returncode == 1
    assert "rejected" in r.stderr.lower()


def test_answer_context_markdown(sample_txt, tmp_path):
    ws = tmp_path / "workspace"
    r = run([str(SCRIPTS / "build_index.py"), str(sample_txt), "--output", str(ws)])
    index_path = json.loads(r.stdout)["index_path"]
    r = run([str(SCRIPTS / "answer_context.py"), "--index", index_path,
             "--query", "renewal terms", "--format", "markdown"])
    assert r.returncode == 0
    assert "# Retrieved evidence" in r.stdout
    assert "# Source map" in r.stdout
