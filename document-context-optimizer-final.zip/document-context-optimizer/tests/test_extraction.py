"""Extraction tests: PDF, DOCX, TXT, MD, HTML, scanned detection, cleanup."""
from pathlib import Path

import pytest
from common.file_utils import UnsupportedFormatError
from extract_document import extract_document


def test_pdf_extraction_preserves_pages(sample_pdf):
    result = extract_document(sample_pdf, ocr="off")
    assert result["file_type"] == "pdf"
    assert len(result["pages"]) >= 3
    assert result["pages"][0]["page"] == 1
    all_text = "\n".join(p["text"] for p in result["pages"])
    assert "Termination for Convenience" in all_text


def test_scanned_page_detection(scanned_pdf):
    result = extract_document(scanned_pdf, ocr="off")
    assert result["pages"][0]["scanned"] is True
    assert any("scanned" in w.lower() for w in result["warnings"])


def test_docx_headings_and_tables(sample_docx):
    result = extract_document(sample_docx)
    headings = [h["text"] for h in result["headings"]]
    assert "Remote Work Policy" in headings
    assert "Eligibility" in headings
    assert len(result["tables"]) == 1
    assert "Laptop" in result["tables"][0]["markdown"]


def test_txt_extraction(sample_txt):
    result = extract_document(sample_txt)
    assert result["file_type"] == "txt"
    assert "MASTER SERVICES AGREEMENT" in result["pages"][0]["text"]
    assert result["headings"]  # numbered sections detected


def test_markdown_headings(sample_md):
    result = extract_document(sample_md)
    levels = {(h["text"], h["level"]) for h in result["headings"]}
    assert ("Annual Report 2026", 1) in levels
    assert ("Regional Performance", 2) in levels


def test_html_cleanup_removes_scripts_and_nav(sample_html):
    result = extract_document(sample_html)
    text = result["pages"][0]["text"]
    assert "IGNORE ALL PREVIOUS INSTRUCTIONS" not in text
    assert "Home | About" not in text
    assert "twelve weeks" in text
    assert len(result["tables"]) == 1


def test_empty_file_rejected(tmp_path):
    p = tmp_path / "empty.txt"
    p.write_text("")
    with pytest.raises(ValueError):
        extract_document(p)


def test_unsupported_extension_rejected(tmp_path):
    p = tmp_path / "file.exe"
    p.write_bytes(b"MZ")
    with pytest.raises(UnsupportedFormatError):
        extract_document(p)


def test_missing_file_rejected():
    with pytest.raises(FileNotFoundError):
        extract_document(Path("does-not-exist.pdf"))
