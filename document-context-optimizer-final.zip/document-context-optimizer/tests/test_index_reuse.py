"""Index reuse: cache hit, rebuild on change, rebuild on corrupt index."""
import json

from build_index import build_index


def test_same_file_reuses_index(sample_txt, workspace):
    p1, reused1 = build_index(sample_txt, workspace)
    p2, reused2 = build_index(sample_txt, workspace)
    assert not reused1
    assert reused2
    assert p1 == p2


def test_modified_file_gets_new_index(sample_txt, workspace, tmp_path):
    build_index(sample_txt, workspace)
    modified = tmp_path / "modified.txt"
    modified.write_text(sample_txt.read_text() + "\nNew appended clause about arbitration.")
    p2, reused = build_index(modified, workspace)
    assert not reused  # different hash -> different doc id -> new index


def test_corrupt_index_triggers_rebuild(sample_txt, workspace):
    p1, _ = build_index(sample_txt, workspace)
    p1.write_text("{ not valid json", encoding="utf-8")
    p2, reused = build_index(sample_txt, workspace)
    assert not reused
    data = json.loads(p2.read_text())
    assert data["metadata"]["chunk_count"] > 0


def test_different_chunking_settings_rebuild(sample_txt, workspace):
    build_index(sample_txt, workspace)
    _, reused = build_index(sample_txt, workspace, target_tokens=500, max_tokens=900, min_tokens=100)
    assert not reused
