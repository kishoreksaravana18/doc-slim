"""Retrieval tests: exact phrase, headings, clause numbers, budget, dedup, neighbors."""

from build_index import build_index
from common.retrieval import ScoredChunk, deduplicate, needs_neighbor, select_within_budget
from retrieve_chunks import retrieve


def _index(sample, workspace, **kw):
    path, _ = build_index(sample, workspace, target_tokens=150, max_tokens=300, min_tokens=40, **kw)
    return path


def test_clause_query_finds_termination(sample_txt, workspace):
    index = _index(sample_txt, workspace)
    result = retrieve(index, "Can the customer terminate for convenience?", top_k=3)
    texts = " ".join(r["text"] for r in result["retrieved"])
    assert "Termination for Convenience" in texts
    assert result["retrieved"][0]["page_start"] >= 1


def test_exact_phrase_boost(sample_txt, workspace):
    index = _index(sample_txt, workspace)
    result = retrieve(index, '"sixty days"', top_k=2)
    texts = " ".join(r["text"] for r in result["retrieved"])
    assert "sixty days" in texts


def test_no_results_for_unrelated_query(sample_txt, workspace):
    index = _index(sample_txt, workspace)
    result = retrieve(index, "quantum entanglement spacecraft telemetry", top_k=3)
    assert result["retrieved"] == [] or all(r["score"] < 2 for r in result["retrieved"])


def test_token_budget_enforced():
    meta = {f"c{i}": {"token_count": 1000} for i in range(10)}
    ranked = [ScoredChunk(f"c{i}", 10 - i) for i in range(10)]
    selected, excluded = select_within_budget(ranked, meta, top_k=8, max_tokens=2500, max_chunks=8)
    assert sum(meta[s.chunk_id]["token_count"] for s in selected) <= 3000
    assert len(selected) >= 1  # always keep at least one complete chunk
    assert excluded


def test_deduplication_removes_near_duplicates():
    texts = {
        "a": "the renewal term extends sixty days notice",
        "b": "the renewal term extends sixty days notice",
        "c": "completely different content about payment fees",
    }
    kept = deduplicate([ScoredChunk("a", 5), ScoredChunk("b", 4), ScoredChunk("c", 3)], texts)
    ids = [k.chunk_id for k in kept]
    assert "a" in ids and "c" in ids and "b" not in ids


def test_needs_neighbor_detects_midthought():
    assert needs_neighbor("continues from the previous sentence without capital", {"chunk_type": "prose"})
    assert not needs_neighbor("This is a complete paragraph. It ends properly.", {"chunk_type": "prose"})


def test_metadata_filter_by_type(sample_docx, workspace):
    index = _index(sample_docx, workspace)
    result = retrieve(index, "laptop equipment", top_k=5, filters={"chunk_type": "prose"})
    for r in result["retrieved"]:
        assert r["chunk_type"] == "prose"


def test_heading_match_reason(sample_md, workspace):
    index = _index(sample_md, workspace)
    result = retrieve(index, "regional performance operating margin", top_k=3)
    assert result["retrieved"]
    reasons = {reason for r in result["retrieved"] for reason in r["reasons"]}
    assert "lexical" in reasons
