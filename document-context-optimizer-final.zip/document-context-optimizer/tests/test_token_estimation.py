"""Token estimation and reduction math."""
from common.token_utils import context_reduction_percentage, estimate_tokens


def test_estimate_scales_with_length():
    short = estimate_tokens("hello world")
    long = estimate_tokens("hello world " * 500)
    assert 0 < short < 10
    assert long > short * 100


def test_empty_text_zero():
    assert estimate_tokens("") == 0


def test_reduction_formula():
    assert round(context_reduction_percentage(700_000, 90_000), 2) == 87.14
    assert context_reduction_percentage(0, 100) == 0.0
    assert context_reduction_percentage(100, 100) == 0.0
